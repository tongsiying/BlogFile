#/bin/sh

while true
do
/usr/lib64/sa/sa1 1 1
sleep 5
done
