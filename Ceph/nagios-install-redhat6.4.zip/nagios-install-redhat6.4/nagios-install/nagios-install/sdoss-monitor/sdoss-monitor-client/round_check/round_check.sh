#!/bin/sh 
master_path=`ps -ef|grep weed|grep -v -E '"grep|avahi|vim"'|grep master|grep -v filer|grep -v grep|tr '" "' '"\n"'|grep log|awk -F"=" '{print $2}'`
filer_path=`ps -ef|grep weed|grep -v -E '"grep|avahi|vim"'|grep filer|grep -v grep|tr '" "' '"\n"'|grep log|awk -F"=" '{print $2}'|grep -v subfiler`
subfiler_path=`ps -ef|grep weed|grep -v -E '"grep|avahi|vim"'|grep subfiler|grep -v grep|tr '" "' '"\n"'|grep log|awk -F"=" '{print $2}'`
volume_path=`ps -ef|grep weed|grep -v -E '"grep|avahi|vim"'|grep volume|grep -v master|grep -v filer|grep -v grep|tr '" "' '"\n"'|grep log|awk -F"=" '{print $2}'`

#filer_dir=
#for i in $filer_path
#do
#name=`basename $i`
#if [ $name = 'filer' ]
#then
#   filer_dir=`dirname $i`
#fi
    
#done
#master_path=($master_path)
master_path=/opt/log/sdoss/master
filer_path=($filer_path)
volume_path=($volume_path)
subfiler_path=($subfiler_path)

MASTER_FILE=$master_path/master.log
FILER_FILE=$filer_path/filer.log
SUBFILER_FILE=$subfiler_path/subfiler.log
VOLUME_FILE=$volume_path/volume.log
ip=`/sbin/ifconfig -a|grep -v 192.168.122.1|grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|awk -F':' '{print $2}'`
#WARN_FILE="./warning_"$ip".log"



function send_msg()
{
  msg="��Ѳ�졿"$1
  time=$2
  #receiver="13071518,14042368,13121242,13092212,13073401,14041605,14031171,14042042,14030870,14042402,12120146"
  receiver="13092212"
  msg=$msg "��ȥһСʱ�ڣ���������Ϊ��"$time
  #echo $msg
  curl --header "Content-Type:text/html;charset=GBK" --data '{"alarmSource":"monitor","alarmContent":"'"$msg"'","sendway":"phone","alarmReceiver":"'"$receiver"'"}' http://monitor.cnsuning.com/monitor-alarmcenter/alarmService/alarmNotice  >/dev/null 2>&1
}

function write_file()
{
  file="/usr/lib64/nagios/plugins/round_check/alarm_file.txt"
  msg=$1
  #receiver="13071518,14042368,13121242,13092212,13073401,14041605,14031171,14042042,14030870,14042402,12120146"
  #receiver="13092212"
  if [ "x"`cat $file` = "xnone" ]
  then
   echo $msg>$file
  else
   echo $msg>>$file
  fi
  
  #echo $msg
  #curl --header "Content-Type:text/html;charset=GBK" --data '{"alarmSource":"monitor","alarmContent":"'"$msg"'","sendway":"phone","alarmReceiver":"'"$receiver"'"}' http://monitor.cnsuning.com/monitor-alarmcenter/alarmService/alarmNotice  >/dev/null 2>&1
}


while true
do
   #Check TPS
   ./tail_round.sh >/dev/null 2>&1
   total_file="/usr/lib64/nagios/plugins/round_check/total_file.txt"
   echo "none"> "/usr/lib64/nagios/plugins/round_check/alarm_file.txt"
   t=`cat ${MASTER_FILE} |grep -E " 1000 | 1001 | 1002 | 1003 | 1004 | 1005 | 1006 "|grep "UPLOAD" | wc -l `
   echo $t" " > $total_file
   t=`cat ${MASTER_FILE} |grep -E " 1100 | 1101 | 1102 | 1103 "|grep "DOWNLOAD" | wc -l `
   echo $t" " >> $total_file
   t=`cat ${MASTER_FILE} |grep -E " 1200 | 1201 "|grep "DELETE" | wc -l `
   echo $t" " >> $total_file
   t=`cat ${MASTER_FILE} |grep -E " 2000 | 2001 "|grep "UPLOAD" | wc -l `
   echo $t" " >> $total_file
   t=`cat ${MASTER_FILE} |grep -E " 2100 "|grep "DOWNLOAD" | wc -l `
   echo $t" " >> $total_file
   t=`cat ${MASTER_FILE} |grep -E " 3000 | 3001 | 3002 | 3003 "|grep "UPLOAD" | wc -l `
   echo $t" " >> $total_file
   t=`cat ${MASTER_FILE} |grep -E " 3100 | 3101 | 3102 | 3103 | 3104 "|grep "DOWNLOAD" | wc -l `
   echo $t" " >> $total_file
   t=`cat ${MASTER_FILE} |grep -E " 3200 | 3201 "|grep "DELETE" | wc -l `
   echo $t" " >> $total_file
   t=`cat ${MASTER_FILE} |grep -E " 3300 | 3301 | 3302 | 3303 | 3304 "|grep "FIX" | wc -l `
   echo $t" " >> $total_file
   t=`cat ${MASTER_FILE} |grep -E " 3400 | 3401 | 3402 | 3403 | 3404 | 3405 | 3406 | 3407 "|grep "VACUUM" | wc -l `
   echo $t" " >> $total_file
   

   IFS=,
   while read type des code
   do
     #echo $code" " $des " "  $type
     t=`cat ${MASTER_FILE} |grep -E "UPLOAD|DELETE|DOWNLOAD|FIX|VACUUM"|grep  " $code " |wc -l` # >/dev/null 2>&1
     if [ $t -ne 0 ]
     then
        msg=''"$ip"''" "' '"$code"' '"$t"''
        #echo $msg 
        write_file "$msg"
     fi

     #cat "$FILER_FILE" |grep  " $code " >/dev/null 2>&1
     #cat "$FILER_FILE" |grep  " $code " 
     #if [ $? -eq 0 ]
     #then
     #   msg=''"$ip"''" "' '"$type"': '"$des"''
        #echo $msg 
     #   send_msg $msg
     #fi

     #cat "$SUBFILER_FILE" |grep  " $code " >/dev/null 2>&1
     #if [ $? -eq 0 ]
     #then
     #   msg=''"$ip"''" "' '"$type"': '"$des"''
        #echo $msg 
     #   send_msg $msg
     #fi

     #cat "$VOLUME_FILE" |grep  " $code " >/dev/null 2>&1
     #if [ $? -eq 0 ]
     #then
     #   msg=''"$ip"''" "' '"$type"': '"$des"''
        #echo $msg 
     #   send_msg $msg
     #fi
   done < msg.csv
   IFS=

#   echo > $FILE
done

