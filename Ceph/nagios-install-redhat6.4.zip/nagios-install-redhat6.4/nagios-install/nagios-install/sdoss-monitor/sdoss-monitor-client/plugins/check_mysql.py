#!/usr/bin/python


import commands
import time
import string
import sys
import argparse

WARNING_LEVEL = 80
CRITICAL_LEVEL = 90
INVALID_STATUS_CODE = -1

OK = "OK"
WARNING = "WARNING"
CRITICAL = "CRITICAL"
UNKNOWN = "UNKNOWN"
OK_CODE = 0
WARNING_CODE = 1
CRITICAL_CODE = 2
UNKNOWN_CODE = 3

def parse_input():
    parser = argparse.ArgumentParser()
    parser.add_argument("-w", "--warn", action="store",
                        required=True,type=int,
                        help="Warning threshold in percentage")
    parser.add_argument("-c", "--critical", action="store",
                        required=True, type=int,
                        help="Critical threshold in percentage")
    args = parser.parse_args()
    return args

def check_mysql():
    status=0
    msg="OK.Check mysql OK."
    cmd=''' ps -ef|grep -E "mysqld|mysqld_safe"|grep -v grep '''
    result=commands.getstatusoutput(cmd)
    if result[0] != 0:
        status = 2
        msg = "CRITICAL: Check mysql status failed, mysql is down!"
        print msg
        exit(status)
    cmd=''' ps -ef|grep mysqld|xargs -n1|grep datadir |awk -F"=" '{print $2}' '''
    result=commands.getstatusoutput(cmd)
    if result[0] != 0 or result[1]=='':
        status = 2
        msg = "CRITICAL: Check mysql status failed, mysql is down!"
        print msg
        exit(status)
    path=result[1].strip()
    statusCode, msg, diskPerf = showDiskUsage(args.warn,\
                                              args.critical,\
                                              [path],\
                                              True,\
                                              None,\
                                              False,\
                                              False)
    return statusCode,msg,diskPerf
    

def getVal(val):
    dmatch = re.compile('[0-9]+').match(val)
    if (dmatch):
        return float(eval(dmatch.group(0)))
    else:
        return 0


def getUsageAndFree(path, crit, warn, lvm):
    disk = {'path': path, 'rrqm/s': 0, 'wrqm/s': 0,
            'r/s': 0, 'w/s': 0, 'rkB/s': 0, 'wkB/s': 0, 'avgrq-sz': 0, 'avgqu-sz':0, 'await':0, 'svctm': 0, '%util': 0,
            'status': None, 'msg': None,
            'statusCode': 0}
    status=""
    command= "df -lh " + path +"|awk '{print $1}'|grep Filesystem -A 1 |grep -v Filesystem"
    path=commands.getstatusoutput(command)
    
    command = "iostat -xk 1 -n 2 " + path[1] + "|grep Device -A 1|grep -v Device|tail -n 1"

    status = commands.getstatusoutput(command)
    # Sample output
    # (0, 'Filesystem     1G-blocks  Used Available Use% Mounted on\n/dev/sda1
    #       290G  196G       79G  72% /')
    if status[0] != 0:
        disk['msg'] = 'error:%s' % status[0]
        if status[0] == 256:
            disk['status'] = "Brick/Device path not found!"
        else:
            disk['status'] = status[1]
        disk['statusCode'] = CRITICAL
        return disk

    status = status[1].split()
    disk['rrqm/s'] = status[1]
    disk['wrqm/s'] = status[2]
    disk['r/s'] = status[3]
    disk['w/s'] = status[4]
    disk['rkB/s'] = status[5]
    disk['wkB/s'] = status[6]
    disk['avgrq-sz'] = status[7]
    disk['vgqu-sz'] = status[8]
    disk['await'] = status[9]
    disk['svctm'] = status[10]
    disk['%util'] = status[11]

    if string.atof(disk['%util']) >= float(crit):
        disk['statusCode'] = CRITICAL
    elif string.atof(disk['%util']) >= float(warn):
        disk['statusCode'] = WARNING
    elif string.atof(disk['%util']) < float(warn):
        disk['statusCode'] = OK

    return disk

def showDiskUsage(warn, crit, mountPaths, toListInode, usage=False,
                  isLvm=False, ignoreError=False):
    diskPerf = []
    warnList = []
    critList = []
    okList = []
    mounts = []
    statusCode = INVALID_STATUS_CODE
    totalUsed = 0
    totalSize = 0
    noOfMounts = len(mountPaths)
    maxPercentUsed = 0
    usageMsg = ""

    #for path in mountPaths:
    #    tmp = ""
        #disk = getDisk(path, crit, warn, usage, isLvm)
    disk = getUsageAndFree(mountPaths[0], crit, warn, isLvm)

#        if not disk['used'] or not inode['used']:
#            if not ignoreError:
#                sys.exit(utils.PluginStatusCode.UNKNOWN)

    if disk['path']:
        mounts.append(disk['path'])
    data = ""
    if disk['path']:
       data = "%s=%.2f%s;%d;%d;0;%s" % (
            "%util",
            string.atof(disk['%util']) ,
            "%",
            warn ,
            crit ,
            disk['%util'])
       diskPerf.append(data)

       data = " %s=%s;%.2f;%.2f;0;%s" % (
            "svctm",
            disk['svctm'],
            0 ,
            0 ,
            disk['svctm'])
       diskPerf.append(data)

       data = " %s=%s;%.2f;%.2f;0;%s" % (
            "await",
            disk['await'],
            0 ,
            0 ,
            disk['await'])
       diskPerf.append(data)

       data = " %s=%s;%.2f;%.2f;0;%s" % (
            "avgqu-sz",
            disk['avgqu-sz'],
            0 ,
            0 ,
            disk['avgqu-sz'])
       diskPerf.append(data)

       data = " %s=%s;%.2f;%.2f;0;%s" % (
            "avgrq-sz",
            disk['avgrq-sz'],
            0 ,
            0 ,
            disk['avgrq-sz'])
       diskPerf.append(data)

       data = " %s=%s;%.2f;%.2f;0;%s" % (
            "wkB/s",
            disk['wkB/s'],
            0 ,
            0 ,
            disk['wkB/s'])
       diskPerf.append(data)

       data = " %s=%s;%.2f;%.2f;0;%s" % (
            "rkB/s",
            disk['rkB/s'],
            0 ,
            0 ,
            disk['rkB/s'])
       diskPerf.append(data)
    # adding into status message if there is any
    # specfic status found (short msg for list of disks)
    msg = ""
    disk['fs'] = disk['path']
    if disk['status'] and disk['msg']:
        if noOfMounts == 1:
            msg = "%s=%s(%s)" % (disk['fs'], disk['path'],
                                 disk['status'])
        else:
            msg = "%s(%s)" % (disk['fs'], disk['msg'])
    else:
        if noOfMounts == 1:
           msg = "%s=%s" % (disk['fs'], disk['path'])
        else:
           msg = "%s" % (disk['path'])

    if disk['statusCode'] == CRITICAL: 
        statusCode = CRITICAL_CODE
        critList.append(msg)
    elif (disk['statusCode'] == WARNING): 
        # if any previous disk statusCode is not critical
        # we should not change the statusCode into warning
        if statusCode != CRITICAL_CODE:
            statusCode = WARNING_CODE
        # just adding warning values into the list
        warnList.append(msg)
    elif disk['statusCode'] == OK:
        if statusCode == INVALID_STATUS_CODE or \
           statusCode == OK_CODE:
             statusCode = OK_CODE
        okList.append(msg)
    else:
        # added \ to fix E125 pep8 error
        if statusCode != CRITICAL_CODE or \
           statusCode != WARNING_CODE:
            statusCode = UNKNOWN_CODE
        okList.append(msg)
    #tmp = "%s: rrqm/s  wrqm/s r/s w/s  rkB/s wkB/s avgrq-sz vgqu-sz await svctm util   %s %s %s %s %s %s %s %s %s %s %s " %  (disk['path'],disk['rrqm/s'],disk['wrqm/s'],disk['r/s'],disk['w/s'],disk['rkB/s'],disk['wkB/s'],disk['avgrq-sz'],disk['vgqu-sz'],disk['await'],disk['svctm'],disk['%util'])  
    tmp = ('Path mysql data disk(%s) utils is %s%%' ) % (disk['path'],disk['%util'])
    usageMsg += tmp
    usageMsg +=" \n"
    #msg = _getMsg(okList, warnList, critList)
    #msg = "%util,svctm,await,avgqu-sz,avgrq-sz,wkB/s,rkB/s"
    msg = ""

#    usageMsg = "return brick perforce\n" 
    if usageMsg:
        msg = "%s:mount(s): (%s)" % (usageMsg, msg)
    return statusCode, msg, diskPerf


if __name__ == '__main__':

    try:
        args=parse_input()
        statusCode,msg,diskPerf = check_mysql()
        if CRITICAL_CODE == statusCode:
            sys.stdout.write("%s : %s | %s\n" % (
            CRITICAL,
            msg,
            " ".join(diskPerf)))
            sys.exit(CRITICAL_CODE)
        elif WARNING_CODE == statusCode:
            sys.stdout.write("%s : %s | %s\n" % (
            WARNING,
            msg,
            " ".join(diskPerf)))
            sys.exit(WARNING_CODE)
        else:
            sys.stdout.write("%s : %s | %s\n" % (
            OK,
            msg,
            " ".join(diskPerf)))
            exit(0) 
    except Exception as e:
        print e
        exit(2)
