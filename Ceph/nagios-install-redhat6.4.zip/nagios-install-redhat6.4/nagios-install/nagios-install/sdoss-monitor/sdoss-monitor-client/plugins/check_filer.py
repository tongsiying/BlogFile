#!/usr/bin/python

import commands
import time

def check_redis():
    status=0
    msg='OK.Check filer OK.'
    cmd='ps -ef|grep filer|grep -v grep | grep master'
    result=commands.getstatusoutput(cmd)
    if result[0] != 0:
       status = 2
       msg  = 'CRITICAL.Check filer server failed!'
    return status,msg


if __name__ == '__main__':

    status,msg = check_redis()
    #if status == 0:
    #   exit(0)
    #else :
    #   print "Critical. Check redis failed."
    #   print msg
    #   exit(2) 
    print msg
    exit(status)
