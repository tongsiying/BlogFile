#!/bin/sh

while true
do
pids=`ps -ef|grep nagios|grep python|grep -v grep|awk '{print $2}'`
now=`date +%s`
for pid in $pids
do
   echo $pid
   start_time=`ps -eo pid,lstart|grep $pid|awk '{print $2,$3,$4,$5,$6}'` 
   start_time=`date -d "$start_time" +%s`
   t=`expr $now - $start_time`
   if [ $t -gt 600 ]
   then
      kill -9 $pid >/dev/null 2>&1
   fi
done

sleep 600
#del nmon file
pwd='/opt/nmon'
if [ ! -d $pwd ]
then
continue
fi
count=`ls -l $pwd|wc -l`
echo $count
num=`expr $count - 90`
if [ $num -gt 0 ]
then
    dellist=`ls -ltr $pwd|grep -v total|head -n $num|awk '{print $9}'`
    cd $pwd
    echo $dellist
    rm -rf $dellist
    cd -
fi


done
