#!/bin/sh


if [ $1 = start ]
then
        ps -ef|grep monitor_sdoss.sh |grep -v grep >/dev/null 2>&1
        if [ $? -ne 0 ]
        then
            cd /usr/lib64/nagios/plugins
            bash ./monitor_sdoss.sh >/dev/null 2>&1 &
            cd -
        else
            kill `ps -ef|grep monitor_sdoss.sh|grep -v grep|awk '{print $2}'`
            cd /usr/lib64/nagios/plugins
            bash ./monitor_sdoss.sh >/dev/null 2>&1 &
            cd -
        fi

        ps -ef|grep monitor_nmon.sh |grep -v grep >/dev/null 2>&1
        if [ $? -ne 0 ]
        then
            cd /usr/lib64/nagios/plugins
            bash ./monitor_nmon.sh >/dev/null 2>&1 &
            cd -
        else
            kill `ps -ef|grep monitor_nmon.sh|grep -v grep|awk '{print $2}'`
            cd /usr/lib64/nagios/plugins
            bash ./monitor_nmon.sh >/dev/null 2>&1 &
            cd -
        fi

        ps -ef|grep monitor_python.sh |grep -v grep >/dev/null 2>&1
        if [ $? -ne 0 ]
        then
            cd /usr/lib64/nagios/plugins
            bash ./monitor_python.sh >/dev/null 2>&1 &
            cd -
        else
            kill `ps -ef|grep monitor_python.sh|grep -v grep|awk '{print $2}'`
            cd /usr/lib64/nagios/plugins
            bash ./monitor_python.sh >/dev/null 2>&1 &
            cd -
        fi


#        ps -ef|grep sa.sh |grep -v grep > /dev/null 2>&1
#        if [ $? -ne 0 ]
#        then
#            bash /usr/lib64/nagios/plugins/sa.sh 2>&1 &
#        else
#            kill `ps -ef|grep sa.sh |grep -v grep |awk '{print $2}'`
#            bash /usr/lib64/nagios/plugins/sa.sh 2>&1 &
#        fi
fi

if [ $1 = stop ]
then
        kill `ps -ef|grep sa.sh|grep -v grep|awk '{print $2}'` >/dev/null 2>&1
        kill `ps -ef|grep monitor_sdoss.sh|grep -v grep|awk '{print $2}'` >/dev/null 2>&1
        kill `ps -ef|grep monitor_nmon.sh|grep -v grep|awk '{print $2}'` >/dev/null 2>&1
        kill `ps -ef|grep monitor_python.sh|grep -v grep|awk '{print $2}'` >/dev/null 2>&1
        #kill `ps -ef|grep round_check.sh|grep -v grep|awk '{print $2}'` >/dev/null 2>&1
fi
