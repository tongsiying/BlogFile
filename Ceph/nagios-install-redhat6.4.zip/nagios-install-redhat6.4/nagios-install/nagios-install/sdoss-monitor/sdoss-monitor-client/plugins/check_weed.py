#!/usr/bin/python


import argparse
import pycurl
 
c = pycurl.Curl()

def parse_input():
    parser = argparse.ArgumentParser()
    parser.add_argument("-t", "--type", action="store",
                        required=True, 
                        help="Monitor Weed Type")
    parser.add_argument("-i", "--ip", action="store",
                        required=True,
                        help="Host IP")
#    parser.add_argument("-c", "--critical", action="store",
#                        required=True, type=int,
#                        help="Critical threshold in percentage")
#    sadf.add_common_args(parser)
    args = parser.parse_args()
    return args

def makeUrl(type,host):
    url=''
    if type == 'cluster':
       url="http://" + host +":9333/cluster/status?pretty=y" 
    if type == 'dir':
       url="http://" + host +":9333/dir/status?pretty=y" 
    if type == 'vol':
       url="http://" + host +":8080/status?pretty=y" 
    return url
       


def getStatus():
    try:
        c.perform()
 
    except pycurl.error, error:
        errno, errstr = error
        print 'An error occurred: ', errstr

def initCurl(url):
    c.setopt(c.URL, url)
    c.setopt(c.CONNECTTIMEOUT, 5)
    c.setopt(c.TIMEOUT, 8)
    c.setopt(c.COOKIEFILE, '')
    c.setopt(c.FAILONERROR, True)
    c.setopt(c.HTTPHEADER, ['Accept: text/html', 'Accept-Charset: UTF-8'])


if __name__ == '__main__':
     args=parse_input() 
     initCurl(makeUrl(args.type,args.ip))
     getStatus()
     
     
