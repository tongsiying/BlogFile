#!/bin/sh
pid=$$
master_path=`ps -ef|grep weed|grep -v -E '"grep|avahi|vim"'|grep master|grep -v filer|grep -v grep|tr '" "' '"\n"'|grep log|awk -F"=" '{print $2}'`
filer_path=`ps -ef|grep weed|grep -v -E '"grep|avahi|vim"'|grep filer|grep -v grep|tr '" "' '"\n"'|grep log|awk -F"=" '{print $2}'`
volume_path=`ps -ef|grep weed|grep -v -E '"grep|avahi|vim"'|grep volume|grep -v master|grep -v filer|grep -v grep|tr '" "' '"\n"'|grep log|awk -F"=" '{print $2}'`
file="$volume_path/weed.INFO $volume_path/weed.VOLUMEHTTP $master_path/weed.INFO"
allfile="$volume_path/weed.INFO $volume_path/weed.VOLUMEHTTP $filer_path/weed.FILERHTTP $filer_path/weed.INFO $master_path/weed.INFO"
#hostname=`hostname`
#nmonfile=`ls -ltr /home/nmon/$hostname_*.nmon|tail -n 1|awk '{print $9}'`
tail -f $file --pid=$pid -s 0.1 -n 0 > .tail.log &
tail -f $allfile --pid=$pid -s 0.1 -n 0 > .tail_all.log &
#tail -f $nmonfile --pid=$pid -s 0.1 -n 0 > .nmon.log &
sleep 30
#mv tail.log tail.log.$$
\mv .tail.log .sdoss_status.log
\mv .tail_all.log .sdoss_all.log
#\mv .nmon.log .nmon_all.log
exit 0

