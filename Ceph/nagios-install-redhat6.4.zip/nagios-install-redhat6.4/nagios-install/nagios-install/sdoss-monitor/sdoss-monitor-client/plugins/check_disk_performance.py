#!/usr/bin/python
# Copyright (C) 2014 Red Hat Inc
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
#


import os
import re
import sys
import commands
import string
from optparse import OptionParser
#from glusternagios import utils

WARNING_LEVEL = 80
CRITICAL_LEVEL = 90
INVALID_STATUS_CODE = -1

OK = "OK"
WARNING = "WARNING"
CRITICAL = "CRITICAL"
UNKNOWN = "UNKNOWN"
OK_CODE = 0
WARNING_CODE = 1
CRITICAL_CODE = 2
UNKNOWN_CODE = 3


def getVal(val):
    dmatch = re.compile('[0-9]+').match(val)
    if (dmatch):
        return float(eval(dmatch.group(0)))
    else:
        return 0


def getUsageAndFree(path, crit, warn, lvm):
    disk = {'path': path, 'rrqm/s': 0, 'wrqm/s': 0,
            'r/s': 0, 'w/s': 0, 'rkB/s': 0, 'wkB/s': 0, 'avgrq-sz': 0, 'avgqu-sz':0, 'await':0, 'svctm': 0, '%util': 0,
            'status': None, 'msg': None,
            'statusCode': 0}
    status=""
    l=len(path.split(","))
    #command = "iostat -xk 1 -n 2|grep Device -A " + str(l)  + "|grep Filesystem -B " + str(l) + "|grep -v Device|grep -v Filesystem|grep -v ^$|tail -n " + str(l)
    command = " iostat -xk 1 -n 2|grep File -A 100|grep -v File|grep -v Device|grep -v ^$"
    re = commands.getstatusoutput(command)
    msg=""
    error="OK:"
    result=0
    perfData=""
    for p in path.split(","):
       command = "df -lh " + p +"|awk '{print $1}'|grep Filesystem -A 1 |grep -v Filesystem"
       status=commands.getstatusoutput(command)
       if status[0] != 0:
          if status[0] == 256:
            error = "CRITICAL:Brick/Device path not found!"
            result=2
          else:
            error="CRITICAL:" + status[1]
            result=2
        #return disk

       vdisk=status[1].split("/")[2]
       if vdisk == "mapper":
           vdisk = "dm-0"
       index=re[1].split().index(vdisk)
       status = status[1].split()
       msg+=" sdoss path(" + p + ") util is " + str(re[1].split()[index+11]) + "%"
       perfData+= " util%=" + str(re[1].split()[index+11]) + "%;80;90;0;" +  str(re[1].split()[index+11])
       perfData+= " svctm=" + str(re[1].split()[index+10]) + "%;0.00;0.00;0;" +  str(re[1].split()[index+10])
       perfData+= " await=" + str(re[1].split()[index+9]) + "%;0.00;0.00;0;" +  str(re[1].split()[index+9])
       perfData+= " avgqu-sz=" + str(re[1].split()[index+8]) + "%;0.00;0.00;0;" +  str(re[1].split()[index+8])
       perfData+= " avgrq-sz=" + str(re[1].split()[index+7]) + "%;0.00;0.00;0;" +  str(re[1].split()[index+7])
       perfData+= " wkB/s=" + str(re[1].split()[index+6]) + "%;0.00;0.00;0;" +  str(re[1].split()[index+6])
       perfData+= " rkB/s=" + str(re[1].split()[index+5]) + "%;0.00;0.00;0;" +  str(re[1].split()[index+5])
      
        #disk['rrqm/s'] = status[1]
        #disk['wrqm/s'] = status[2]
        #disk['r/s'] = status[3]
        #disk['w/s'] = status[4]
        #disk['rkB/s'] = status[5]
        #disk['wkB/s'] = status[6]
        #disk['avgrq-sz'] = status[7]
        #disk['vgqu-sz'] = status[8]
        #disk['await'] = status[9]
        #disk['svctm'] = status[10]
        #disk['%util'] = status[11]

        #if string.atof(disk['%util']) >= float(crit):
        #   disk['statusCode'] = CRITICAL
        #elif string.atof(disk['%util']) >= float(warn):
        #   disk['statusCode'] = WARNING
        #elif string.atof(disk['%util']) < float(warn):
        #   disk['statusCode'] = OK
       if string.atof(str(re[1].split()[index+11])) >= float(crit):
           error="CRITICAL:"
           result=2
       if string.atof(str(re[1].split()[index+11])) >= float(crit):
           error="WARNING:"
           result=1
    final=error + msg + "\n" + ":mount(s): () |" + perfData
    return final,result


#def getDisk(path, crit, warn, usage=None, lvm=False):
#    if usage:
#        return getUsageAndFree("df -B%s %s" % (usage, path),
#                               path, crit, warn, lvm)
#    else:
#        return getUsageAndFree("df -BG %s" % path,
#                               path, crit, warn, lvm)


#def getInode(path, crit, warn, lvm=False):
#    return getUsageAndFree("df -i %s" % path,
#                           path, crit, warn, lvm)


def getMounts(searchQuery, excludeList=[]):
    mountPaths = []
    f = open("/etc/mtab")
    for i in f.readlines():
        if i.startswith(searchQuery):
            if not excludeList:
                mountPaths.append(i.split()[0])
            else:
                device = i.split()
                if not device[0] in options.exclude and\
                   not device[1] in options.exclude:
                    mountPaths.append(device[0])
    f.close()
    return mountPaths


def parse_input():
    parser = OptionParser()
    parser.add_option('-w', '--warning', action='store', type='int',
                      dest='warn',
                      help='Warning count in %', default=WARNING_LEVEL)
    parser.add_option('-c', '--critical', action='store', type='int',
                      dest='crit',
                      help='Critical count in %', default=CRITICAL_LEVEL)
    parser.add_option('-u', '--usage', action="store", dest='usage',
                      help='Usage in %/GB/MB/KB', default=None)
    parser.add_option('-l', '--lvm', action="store_true",
                      dest='lvm',
                      help='List lvm mounts', default=False)
    parser.add_option('-d', '--inode', action="store_true", dest='inode',
                      help='List inode usage along with disk/brick usage',
                      default=False)
    parser.add_option('-a', '--all', action="store_true",
                      dest='all',
                      help='List all mounts', default=False)
    parser.add_option('-n', '--ignore', action="store_true",
                      dest='ignore',
                      help='Ignore errors', default=False)
    parser.add_option('-i', '--include', action='append', type='string',
                      dest='mountPath',
                      help='Mount path', default=[])
    parser.add_option('-x', '--exclude', action="append", type='string',
                      dest='exclude',
                      help='Exclude disk/brick')
    return parser.parse_args()


def _getMsg(okList, warnList, critList):
    msg = ", ".join(critList)
    if critList and (warnList or okList):
        msg = "CRITICAL: " + msg
    if warnList:
        if msg:
            msg += "; WARNING: "
        msg += ", ".join(warnList)
    if okList:
        if msg:
            msg += "; OK: "
        msg += ", ".join(okList)
    return msg


"""def _getUnitAndType(val):
    unit = utils.convertSize(val, "GB", "TB")
    if unit >= 1:
        return unit, "TB"
    else:
        return val, "GB"
"""


def showDiskUsage(warn, crit, mountPaths, toListInode, usage=False,
                  isLvm=False, ignoreError=False):
    diskPerf = []
    warnList = []
    critList = []
    okList = []
    mounts = []
    statusCode = INVALID_STATUS_CODE
    totalUsed = 0
    totalSize = 0
    noOfMounts = len(mountPaths)
    maxPercentUsed = 0
    usageMsg = ""

    #for path in mountPaths:
    #    tmp = ""
        #disk = getDisk(path, crit, warn, usage, isLvm)
    msg,result = getUsageAndFree(mountPaths[0], crit, warn, isLvm)

#        if not disk['used'] or not inode['used']:
#            if not ignoreError:
#                sys.exit(utils.PluginStatusCode.UNKNOWN)

    return result, msg


def get_path():
    cmd='''ps -ef|grep weed|grep -v grep |grep server|xargs -n1|grep -w dir|awk -F"=" '{print $2}' '''
    out=commands.getstatusoutput(cmd)
    if out[0] != 0:
        print "CRITICAL:Can't get SDOSS data path."
        exit(2)
    return out[1].split()

if __name__ == '__main__':
    (options, args) = parse_input()
    options.mountPath=get_path()
    if len(options.mountPath) == 0:
        print "CRITICAL:SDOSS is down!"
        exit(2)

    if options.lvm:
        searchQuery = "/dev/mapper"
    else:
        searchQuery = "/"

    #if not options.mountPath or options.lvm or options.all:
    #options.mountPath += getMounts(searchQuery, options.exclude)

    statusCode, msg= showDiskUsage(options.warn,\
                                              options.crit,\
                                              options.mountPath,\
                                              options.inode,\
                                              options.usage,\
                                              options.lvm,\
                                              False)
    print msg
    exit(statusCode)
