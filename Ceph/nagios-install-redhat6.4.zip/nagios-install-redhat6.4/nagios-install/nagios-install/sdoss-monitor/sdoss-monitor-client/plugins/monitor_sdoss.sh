#!/bin/sh
FILE='./.sdoss_status.log'
ALLFILE='./.sdoss_all.log'
#WARN_FILE='/home/loguser/warning.log'
SUM_FILE='./nginx_all.log'
MAX200=100
MAX404=30
MAX304=30
MAXTPS=100
TRAFFIC_MAX=2000
NGINX_MAX=8
ip=`/sbin/ifconfig -a|grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|awk -F':' '{print $2}'`
WARN_FILE="./warning_"$ip".log"

while true
do
   #Check TPS
   ./tail_sdoss.sh >/dev/null 2>&1
   max200=0
   max304=0
   max404=0
   maxsum=0
   maxtraffic=0
   time1=`date +%s` 
   time=0
   for i in $(seq 6)
   do
   time=`expr $time1 - 35 + $i \* 5`
#   echo $time
   t0=$time
   t1=`expr $time + 1`
   t2=`expr $time + 2`
   t3=`expr $time + 3`
   t4=`expr $time + 4`
   
   t0=`date -d @$t0`
   t1=`date -d @$t1`
   t2=`date -d @$t2`
   t3=`date -d @$t3`
   t4=`date -d @$t4`

   t0=`echo $t0|awk '{print $3"/"$2"/"$6":"$4}'`
   t1=`echo $t1|awk '{print $3"/"$2"/"$6":"$4}'`
   t2=`echo $t2|awk '{print $3"/"$2"/"$6":"$4}'`
   t3=`echo $t3|awk '{print $3"/"$2"/"$6":"$4}'`
   t4=`echo $t4|awk '{print $3"/"$2"/"$6":"$4}'`
   TPS200=`cat $FILE |grep -w GET|grep -w 200|grep -E "$t0|$t1|$t2|$t3|$t4"|wc -l`
   TPS200=`expr $TPS200 / 5 `
   if [ $TPS200 -gt $max200 ]
   then
      max200=$TPS200
   fi
   #if [ $TPS200 -gt $MAX200 ]
   #then
   #    echo `date` " WARNING: REQUEST 200 TPS IS "$TPS200 >$WARN_FILE
   #fi
   TPS404=`cat $ALLFILE |grep -w GET|grep -w 404|grep -E "$t0|$t1|$t2|$t3|$t4"|wc -l`
   TPS404=`expr $TPS404 / 5 `
   if [ $TPS404 -gt $max404 ]
   then
      max404=$TPS404
   fi
   #if [ $TPS404 -gt $MAX404 ]
   #then
   #    echo `date` " WARNING: REQUEST 404 TPS IS "$TPS404 >>$WARN_FILE
   #fi

   TPS304=`cat $ALLFILE |grep -w GET|grep -w 304|grep -E "$t0|$t1|$t2|$t3|$t4"|wc -l`
   TPS304=`expr $TPS304 / 5 `
   if [ $TPS304 -gt $max304 ]
   then
      max304=$TPS304
   fi
   #if [ $TPS304 -gt $MAX304 ]
   #then
   #    echo `date` " WARNING: REQUEST 304 TPS IS "$TPS304 >>$WARN_FILE
   #fi

   TPS=`cat $ALLFILE |grep -w GET|grep -w -E "200|201|202|404|304|500"|grep -E "$t0|$t1|$t2|$t3|$t4"|wc -l`
   TPS=`expr $TPS / 5 `
   if [ $TPS -gt $maxsum ]
   then 
      maxsum=$TPS
   fi  
   #if [ $TPS -gt $MAXTPS ]
   #then
   #    echo `date` " WARNING: REQUEST SUM TPS IS "$TPS >>$WARN_FILE
   #fi

   TRAFFIC=`cat $ALLFILE |grep -E "$t0|$t1|$t2|$t3|$t4"| awk '{sum+=$10} END {print sum/1024}'`
   TRAFFIC=`awk 'BEGIN{print '"$TRAFFIC"'/5 }'`
   if [[ `echo "$TRAFFIC > $maxtraffic"|bc` -eq 1 ]]
   then
        maxtraffic=$TRAFFIC
   fi
   #if [[ `echo "$TRAFFIC > $TRAFFIC_MAX"|bc` -eq 1 ]]
   #then
   #    echo `date` " WARNING: NGINX TRAFFIC BUSY: " $TRAFFIC >>$WARN_FILE
   #fi
   #Check nginx connection
   #con=`curl http://127.0.0.1/NginxStatus`
   #out=$?
   #if [ $out -ne 0 ]
   #then
   #    echo `date` " WARNING: NGINX IS DOWN! RETURN CODE IS: "$out >>$WARN_FILE
   #    continue
   #fi
   #con=`echo $con|awk '{print $3}'`
#   echo $con
   #if [[ $con -gt  $NGINX_MAX ]]
   #then
   #    echo `date` " WARNING: NGING'S CONNECTIONS EXTEND MAX: "$con >>$WARN_FILE
   #fi
   #echo `date` "TPS SUM = " $TPS "; 200TPS = " $TPS200 "; 404TPS = " $TPS404 "; Traffic = " $TRAFFIC "; Nginx Connections = " $con >> $SUM_FILE
   done
   echo `date` "TPS SUM = " $maxsum "; 200TPS = " $max200 "; 404TPS = " $max404 "; 304TPS = " $max304 "; Traffic = " $maxtraffic  >> $SUM_FILE
   if [ `ls -l $SUM_FILE|awk '{print $5}'` -gt 10240000 ]
   then
      echo > $SUM_FILE
   fi
#   echo > $FILE
done

