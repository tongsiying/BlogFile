#!/usr/bin/python


import argparse
import pycurl
import sys
 
c = pycurl.Curl()

def parse_input():
    parser = argparse.ArgumentParser()
    parser.add_argument("-t", "--type", action="store",
                        required=True, 
                        help="Monitor Weed Type")
    parser.add_argument("-i", "--ip", action="store",
                        required=True,
                        help="Host IP")
#    parser.add_argument("-c", "--critical", action="store",
#                        required=True, type=int,
#                        help="Critical threshold in percentage")
#    sadf.add_common_args(parser)
    args = parser.parse_args()
    return args

def makeUrl(type,host):
    url=''
    if type == 'cluster':
       url="http://" + host +":9333/cluster/status?pretty=y" 
    if type == 'directory':
       url="http://" + host +":9333/dir/status?pretty=y" 
    if type == 'volume':
       url="http://" + host +":8080/status?pretty=y" 
    if type == 'nginx':
       url="http://" + host +"/NginxStatus"
    if type == 'nginx_conn':
       url="http://" + host +"/NginxStatus"
    if type == 'request':
       url="http://" + host + ":8080/stats/request?pretty=y"
    if type == 'request_filer':
       url="http://" + host + ":8888/stats/request?pretty=y"
    if type == 'tps':
       url="http://" + host + ":8080/stats/tps?pretty=y"
    if type == 'tps_filer':
       url="http://" + host + ":8888/stats/tps?pretty=y"
    return url
       
errno=0
errstr=''


def getStatus():
    global errstr 
    global errno
    #sys.stdout=open('/dev/null','w')
    try:
        c.perform()
    except pycurl.error, error:
        errno, errstr = error
       # print 'An error occurred: ', errstr
       # print 'An errorno: ', errno
        

def initCurl(url):
    c.setopt(c.URL, url)
    c.setopt(c.CONNECTTIMEOUT, 5)
    c.setopt(c.TIMEOUT, 8)
    c.setopt(c.COOKIEFILE, '')
    c.setopt(c.FAILONERROR, True)
    c.setopt(c.VERBOSE, 0)
    c.setopt(c.HTTPHEADER, ['Accept: text/html', 'Accept-Charset: UTF-8'])


if __name__ == '__main__':
   try:
     args=parse_input() 
     initCurl(makeUrl(args.type,args.ip))
     getStatus()
     if errno > 2:
        errno = 2
        print errstr 
     exit(errno)
     
   except Exception as e:
        print e
        exit(2)
