#!/usr/bin/python


import commands
import argparse
import json
import tps_common

INTERNAL = 5

NGINX_MAX=8
THRESHOLD20X = 1000000
THRESHOLD304 = 30000
THRESHOLD3XX = 30000
THRESHOLD404 = 30000
THRESHOLD4XX = 30000
THRESHOLD5XX = 30000
THRESHOLDSUM = 1000000
THRESHOLDTRAFFIC_20X = 200000000

true=True

def parse_input():
    parser = argparse.ArgumentParser()
    parser.add_argument("-t", "--type", action="store",
                        required=True,
                        help="Monitor Tps Type.\n 200,304,404,500,sum,traffic")
    parser.add_argument("-l", "--hosts", action="store",
                        required=True,
                        help="Hosts IP")
#    parser.add_argument("-c", "--critical", action="store",
#                        required=False,type=int,
#                        help="Request Threshold")
#    parser.add_argument("-c", "--critical", action="store",
#                        required=True, type=int,
#                        help="Critical threshold in percentage")
#    sadf.add_common_args(parser)
    args = parser.parse_args()
    return args

def get_tps(s):
    data=json.dumps(s)
    data=eval(eval(data))
    stat={"20X":{},"304":{},"3XX":{},"404":{},"4XX":{},"5XX":{},"traffic_20X":{},"sum":{}}
    if args.type == "get":
       stat["20X"]["count"] = data['TpsStatic']['FilerGet']['Tps_20X'] / INTERNAL
       stat["304"]["count"] = data['TpsStatic']['FilerGet']['Tps_304'] / INTERNAL
       stat["3XX"]["count"] = data['TpsStatic']['FilerGet']['Tps_3XX'] / INTERNAL
       stat["404"]["count"] = data['TpsStatic']['FilerGet']['Tps_404'] / INTERNAL
       stat["4XX"]["count"] = data['TpsStatic']['FilerGet']['Tps_4XX'] / INTERNAL
       stat["5XX"]["count"] = data['TpsStatic']['FilerGet']['Tps_5XX'] / INTERNAL
       stat["traffic_20X"]["count"] = data['TpsStatic']['FilerGet']['Traffic_20X']  / INTERNAL
       stat["sum"]["count"] = sum(data['TpsStatic']['FilerGet'].values())
    #stat["traffic"] = data['TpsStatic']['FilerGet']['Tps_5XX'] + data['TpsStatic']['FilerPost']['Tps_5XX']
    elif args.type == "post":
       stat["20X"]["count"] = data['TpsStatic']['FilerPost']['Tps_20X'] / INTERNAL
       stat["304"]["count"] = data['TpsStatic']['FilerPost']['Tps_304'] / INTERNAL
       stat["3XX"]["count"] = data['TpsStatic']['FilerPost']['Tps_3XX'] / INTERNAL
       stat["404"]["count"] = data['TpsStatic']['FilerPost']['Tps_404'] / INTERNAL
       stat["4XX"]["count"] = data['TpsStatic']['FilerPost']['Tps_4XX'] / INTERNAL
       stat["5XX"]["count"] = data['TpsStatic']['FilerPost']['Tps_5XX'] / INTERNAL
       stat["traffic_20X"]["count"] = data['TpsStatic']['FilerPost']['Traffic_20X'] / INTERNAL
       stat["sum"]["count"] = sum(data['TpsStatic']['FilerPost'].values()) / INTERNAL

    return stat

if __name__=='__main__':
  try:
    args=parse_input()
    code=0
    msg=''
    hosts=args.hosts.split(",")
    count=len(hosts)
    result={"20X":{},"304":{},"3XX":{},"404":{},"4XX":{},"5XX":{},"traffic_20X":{},"sum":{}}
    result["20X"]["status"] = "OK"
    result["304"]["status"] = "OK"
    result["3XX"]["status"] = "OK"
    result["404"]["status"] = "OK"
    result["4XX"]["status"] = "OK"
    result["5XX"]["status"] = "OK"
    result["traffic_20X"]["status"] = "OK"
    result["sum"]["status"] = "OK"
    result["20X"]["count"] = 0
    result["304"]["count"] = 0
    result["3XX"]["count"] = 0
    result["404"]["count"] = 0
    result["4XX"]["count"] = 0
    result["5XX"]["count"] = 0
    result["traffic_20X"]["count"] = 0
    result["sum"]["count"] = 0
    for host in hosts:
       #cmd='/usr/lib64/nagios/plugins/check_weed_status.py -t tps_filer -i ' + host
       #re=commands.getstatusoutput(cmd)
       #if re[0] != 0:
          #code=2 
          #msg="CRITICAL: Check request failed." 
          #print msg
          #exit(code)
       #   continue

       stat=tps_common.get_tps(args.type,host,"tps_filer")
       stat=stat[args.type]
#       if args.type == "get":
#          print "x"*100
       result["20X"]["count"] += stat['20X']['count']
       result["304"]["count"] += stat['304']['count']
       result["3XX"]["count"] += stat['3XX']['count']
       result["404"]["count"] += stat['404']['count']
       result["4XX"]["count"] += stat['4XX']['count']
       result["5XX"]["count"] += stat['5XX']['count']
       result["traffic_20X"]["count"] += stat['traffic_20X']['count']
       result["sum"]["count"] += stat['sum']['count']
#       elif args.type == "post":
#          result["20X"]["count"] += stat['Tpsresultic']['FilerPost']['Tps_20X']
#          result["304"]["count"] += stat['Tpsresultic']['FilerPost']['Tps_304']
#          result["3XX"]["count"] += stat['Tpsresultic']['FilerPost']['Tps_3XX']
#          result["404"]["count"] += stat['Tpsresultic']['FilerPost']['Tps_404']
#          result["4XX"]["count"] += stat['Tpsresultic']['FilerPost']['Tps_4XX']
#          result["5XX"]["count"] += stat['Tpsresultic']['FilerPost']['Tps_5XX']
#          result["traffic_20X"]["count"] += stat['Tpsresultic']['FilerPost']['Traffic_20X']
#          result["sum"]["count"] += sum(stat['Tpsresultic']['FilerPost'].values())
       
   
    #if result["200"]["count"] >= THRESHOLD200:
    #   result["200"]["status"] = "CRITICAL"
    #   code=2
    if result["20X"]["count"] >= THRESHOLD20X * count:
       result["20X"]["status"] = "CRITICAL" 
       code=2
    if result["304"]["count"] >= THRESHOLD304 * count:
       result["304"]["status"] = "CRITICAL"
       code=2
    if result["3XX"]["count"] >= THRESHOLD3XX * count:
       result["3XX"]["status"] = "CRITICAL" 
       code=2
    if result["404"]["count"] >= THRESHOLD404 * count:
       result["404"]["status"] = "CRITICAL" 
       code=2
    if result["4XX"]["count"] >= THRESHOLD4XX * count:
       result["4XX"]["status"] = "CRITICAL"
       code=2
    if result["traffic_20X"]["count"] >=THRESHOLDTRAFFIC_20X * count:
       result["traffic_20X"]["status"] = "CRITICAL" 
       code=2
    if result["5XX"]["count"] >= THRESHOLD5XX * count:
       result["5XX"]["status"] = "CRITICAL" 
       code=2
    if result["sum"]["count"] >= THRESHOLDSUM * count:
       result["sum"]["status"] = "CRITICAL"
       code=2

    msg="Sdoss Status Sumary: " 
    for v in result.keys():
         msg += v + "[tps:" + str(result[v]["count"]) + " status:" + result[v]["status"] + "] "
    msg +="|"
    for v in result.keys():
         #if v == '200':
         #    msg += v + "=" + str(result[v]["count"]) + ";" + str(THRESHOLD200) + ";" + str(THRESHOLD200) + " "
         if v == '20X':
             msg += v + "=" + str(result[v]["count"]) + ";" + str(THRESHOLD20X*count) + ";" + str(THRESHOLD20X*count) + " "
         if v == '304':
             msg += v + "=" + str(result[v]["count"]) + ";" + str(THRESHOLD304*count) + ";" + str(THRESHOLD304*count) + " "
         if v == '3XX':
             msg += v + "=" + str(result[v]["count"]) + ";" + str(THRESHOLD3XX*count) + ";" + str(THRESHOLD3XX*count) + " "
         if v == '404':
             msg += v + "=" + str(result[v]["count"]) + ";" + str(THRESHOLD404*count) + ";" + str(THRESHOLD404*count) + " "
         if v == '4XX':
             msg += v + "=" + str(result[v]["count"]) + ";" + str(THRESHOLD4XX*count) + ";" + str(THRESHOLD4XX*count) + " "
         if v == '5XX':
             msg += v + "=" + str(result[v]["count"]) + ";" + str(THRESHOLD5XX*count) + ";" + str(THRESHOLD5XX*count) + " "
         if v == 'traffic_20X':
             msg += v + "=" + str(result[v]["count"]) + ";" + str(THRESHOLDTRAFFIC_20X*count) + ";" + str(THRESHOLDTRAFFIC_20X*count) + " "
         if v == 'sum':
             msg += v + "=" + str(result[v]["count"]) + ";" + str(THRESHOLDSUM*count) + ";" + str(THRESHOLDSUM*count) + " "
    print msg
    exit(code)
  except Exception as e:    
    print "CRITICAL: Exception:" + str(e)
    exit(0)
