#!/usr/bin/python


import commands
import argparse

NGINX_MAX=8

def parse_input():
    parser = argparse.ArgumentParser()
    parser.add_argument("-l", "--list", action="store",
                        required=True,
                        help="sdoss master server list")
#    parser.add_argument("-i", "--ip", action="store",
                        #required=True,
                        #help="Host IP")
#    parser.add_argument("-e", "--leader", action="store",
#                        required=True,
#                        help="sdoss leader server")
#    parser.add_argument("-c", "--critical", action="store",
#                        required=True, type=int,
#                        help="Critical threshold in percentage")
#    sadf.add_common_args(parser)
    args = parser.parse_args()
    return args

if __name__=='__main__':
  try:
    code=0
    msg=''
    typemsg=''
    args=parse_input()
    leaders=[]

    msg="OK: Check sdoss directory OK."
    peers=args.list
    if peers == 'None':
         print "CRITICAL: Check sdoss failed,no master server found."
         exit(2)
    peers=peers.split(",")
    online=len(peers)
    for peer in peers:
        cmd='/usr/lib64/nagios/plugins/check_weed_status.py -t directory' + ' -i ' + peer
        out=commands.getstatusoutput(cmd)
        if out[0] != 0:
            online=online-1
            continue
            #if online < 2:
            #   print "CRITICAL: Check sdoss directory failed.return:" + out[1]
            #   exit(2)
        x=out[1].split()
        if x.__contains__('"writables":'):
             i=x.index('"writables":')
             if x[i+2] == ']':
                 code=2
                 msg="CRITICAL: No available volume found."
        else:
                 code=2
                 msg="CRITICAL: No available volume found."
    #if set(leaders).pop() != args.leader:
    #    msg="CRITICAL: Check SDOSS cluster failed, wrong leader server found!"
    #    code=2

    print msg
    exit(code)
  except Exception as e:    
    print e
    exit(2)
    

   
