#!/usr/bin/python


import commands
import argparse
import json

NGINX_MAX=8
true=True
false=False
null=""

def parse_input():
    parser = argparse.ArgumentParser()
    parser.add_argument("-t", "--type", action="store",
                        required=True,
                        help="Monitor Weed Type.\n directory,cluster,volume,nginx,nginx_conn")
    parser.add_argument("-i", "--ip", action="store",
                        required=True,
                        help="Host IP")
    parser.add_argument("-c", "--critical", action="store",
                        required=False,
                        help="Nginx connections")
#    parser.add_argument("-c", "--critical", action="store",
#                        required=True, type=int,
#                        help="Critical threshold in percentage")
#    sadf.add_common_args(parser)
    args = parser.parse_args()
    return args

if __name__=='__main__':
  try:
    code=0
    msg=''
    typemsg=''
    args=parse_input()
    if args.type == "nginx_conn":
        typemsg="nginx connections count"
    elif args.type == "nginx":
        typemsg="nginx status"
    else:
        typemsg="SDOSS " + args.type + " status"
    cmd='/usr/lib64/nagios/plugins/check_weed_status.py -t ' + args.type + ' -i ' + args.ip# + '>.result.txt 2>&1';
    re=commands.getstatusoutput(cmd)
    if re[0] == 0:
       msg="OK. check " + typemsg + " OK."# + re[1]
    else:
       code=2 
       msg="CRITICAL: Check " + typemsg + " failed." + re[1]
       print msg
       exit(2)
    # check nginx connetion number
    if args.type == 'nginx_conn':
       if int(args.critical) != 0:
             NGINX_MAX=args.critical
       count=re[1].split()[2]
       if int(count) >= int(NGINX_MAX):
           code=1
           msg="WARNING: Check Nginx Connections extend max threshold return:" + str(count) + "\nWARNING|connections=" + str(count) + ";8;10;0;"+str(count)
       else:
           code=0
           msg="OK: Check Nginx Connections OK return:" + str(count) + "\nOK|connections=" + str(count)+";8;10;0;"+str(count)
            
    # check weed dir 
    if args.type == 'directory':
        x=re[1].split()
        if x.__contains__('"writables":'):
             i=x.index('"writables":')
             if x[i+2] == ']':
                 code=2
                 msg="CRITICAL: No available volume found."
        else:
                 code=2
                 msg="CRITICAL: No available volume found."
    # check writeable volume
    if args.type == 'volume':
       out=json.dumps(re[1])
       out=eval(eval(out))
       volumes=out['Volumes']
       l=len(volumes)
       writableList=[]
       for i in range(l):
           if volumes[i]['CanWrite'] == true:
              writableList.append(volumes[i]['Id'])
       wlen=len(writableList)
       if  writableList == []:
              code=2
              msg="CRITICAL: Writeable/Total:0/%d" %(l)
       else:
              code=0
              msg="OK: Writeable/Total:%d/%d" % (wlen,l)
       


    # check weed cluster
    if args.type == 'cluster':
        out=re[1].split()
        #get leader
        leaders=[]
        if not out.__contains__("\"Leader\":"):
             code=2
             msg="CRITICAL: No available volume found."
             print msg
             exit(code)
             
        ileader=out.index("\"Leader\":")
        leaders.append(out[ileader+1].split(":")[0].replace("\"",""))

        peers=[]
        idx1=out.index('[') 
        idx2=out.index(']')
        for i in range(idx1+1,idx2) :
             peers.append(out[i].split(":")[0].replace("\"",""))
        #check every peers
        for peer in peers:
           cmd='/usr/lib64/nagios/plugins/check_weed_status.py -t cluster' + ' -i ' + peer
           out=commands.getstatusoutput(cmd)
           if out[0] != 0:
                #msg="CRITICAL: Check SDOSS Cluster failed on server " + peer + "return:" + re[1]
                #print msg
                continue
           out=out[1].split()
           ileader=out.index("\"Leader\":")
           leaders.append(out[ileader+1].split(":")[0].replace("\"",""))
        if len(set(leaders)) != 1:
            msg="CRITICAL: Check SDOSS cluster failed, multi leaders found!"
            code=2 

    print msg
    exit(code)
  except Exception as e:    
    print e
    exit(2)
    

   
