#!/usr/bin/python


import commands
import argparse

NGINX_MAX=8

def parse_input():
    parser = argparse.ArgumentParser()
    parser.add_argument("-l", "--list", action="store",
                        required=True,
                        help="sdoss master server list")
#    parser.add_argument("-i", "--ip", action="store",
                        #required=True,
                        #help="Host IP")
#    parser.add_argument("-e", "--leader", action="store",
#                        required=True,
#                        help="sdoss leader server")
#    parser.add_argument("-c", "--cluster", action="store",
#                        required=True, type=int,
#                        help="cluster name")
    args = parser.parse_args()
    return args

if __name__=='__main__':
  try:
    code=0
    msg=''
    typemsg=''
    args=parse_input()
    leaders=[]

    peers=args.list
    if peers == 'None':
         print "CRITICAL: Check sdoss failed,no master server found."
         exit(2)
    peers=peers.split(",")
    numOfmaster=len(peers)
    online=numOfmaster
    for peer in peers:
        cmd='/usr/lib64/nagios/plugins/check_weed_status.py -t cluster' + ' -i ' + peer
        out=commands.getstatusoutput(cmd)
        if out[0] != 0:
            online=online-1
            if online < 2:
                msg="CRITICAL: Check SDOSS Cluster failed, not enough master servers found!"
                print msg
                exit(2)
            else:
                continue
        out=out[1].split()
        if not out.__contains__("\"Leader\":"):
              print "CRITICAL: Check SDOSS cluster failed, cannot find leader on server:" + peer
              exit(2)
        ileader=out.index("\"Leader\":")
        leader=out[ileader+1].split(":")[0].replace("\"","")
        leaders.append(leader)
    if len(set(leaders)) != 1:
        msg="CRITICAL: Check SDOSS cluster failed, more than one leader found! leaders :"
        for l in set(leaders):
            msg += l+' '
        code=2 
    else:
        msg="OK: Check SDOSS cluster OK, leader is: " + set(leaders).pop()
        code=0
    #if set(leaders).pop() != args.leader:
    #    msg="CRITICAL: Check SDOSS cluster failed, wrong leader server found!"
    #    code=2

    print msg
    exit(code)
  except Exception as e:    
    print e
    exit(2)
    

   
