#!/bin/bash
#!/usr/bin/expect
usage()
{
  echo "usage:"
  echo "   ./monitorui-install.sh server netdev"
  echo "example:"
  echo "   ./monitorui-install.sh server eth1 "
  echo "   ./monitorui-install.sh client serverip" 
  echo "example:"
  echo "   ./monitorui-install.sh client 10.27.38.30"
  exit
}


if [ $# = 0 ];
then 
  usage
fi


if [ $1 = client ];
then
   if [ $# -ne 2 ];
   then
   usage
   fi
fi

if [ $1 = server ];
then
   if [ $# -ne 2 ];
   then
   usage
   fi
fi

if [ $1 = help ];
then 
   usage
fi

type=$1
########################################################
####                                                ####
####          Install Monitor-UI Client             ####
####                                                ####
########################################################
if [ $type = client ];
then
nagios_server_ip=$2
#install all required rpms
#if test -f "/etc/redhat-release"; then
#verno=`cat /etc/redhat-release |awk '{print $7}'`
#if [ "$verno" = "6.3" ];then
mkdir /opt/nmon >/dev/null 2>&1
echo "OS is redhat 6.3..."
useradd nrpe
rpm -ivh sdoss-monitor-client/deps-rhel63/*.rpm --force --nodeps
code=-1
if [ $? != 0 ];then
echo "monitorui depend pkg already installed"
fi

#chmod +x sdoss-monitor-client/plugins/*
#chmod +x sdoss-monitor-client/cfg/*
rpm -ivh sdoss-monitor-client/rpms-rhel63/*.rpm --force --nodeps
#copy self-defined files like monitor py .etc
#unalias cp
\cp -rf sdoss-monitor-client/plugins/* /usr/lib64/nagios/plugins
\cp -rf sdoss-monitor-client/cfg/nrpe.cfg /etc/nagios
\cp -rf sdoss-monitor-client/cfg/sdoss-monitor /etc/init.d/
\cp -rf sdoss-monitor-client/plugins/start.sh  /usr/lib64/nagios/plugins
\cp -rf sdoss-monitor-client/plugins/start.py  /usr/lib64/nagios/plugins
\cp -rf sdoss-monitor-client/cfg/sdoss.crontab  /etc/cron.d/
\cp -rf sdoss-monitor-client/round_check  /usr/lib64/nagios/plugins/
chmod -R +x /usr/lib64/nagios/plugins/*
chmod +x /etc/init.d/sdoss-monitor

#delete sar log
#sadf -x -- -r >/dev/null 2>&1
#if [ $? -ne 0 ]
#then
#rm -f /var/log/sa/*
#fi

rm -rf /etc/cron.d/gluster-sysstat.crontab
#echo "59 23 * * * root /usr/lib64/sa/sa1 60 2">/etc/cron.d/sdoss.crontab
#echo "* * * * * root sleep 5;/usr/lib64/sa/sa1 1 1">>/etc/cron.d/sdoss.crontab
service crond start
chkconfig crond on

yum install sysstat -y

#nmon start
#ps -ef|grep nmon|grep 17280|grep -v grep >/dev/null 2>&1
#if [ $? -ne 0 ]
#then
#/nmon/nmon_x86_64_rhel6 -f -N -m /home/nmon -s 5 -c 17280
#fi

#modify some config files
cat /etc/hosts.allow|grep $nagios_server_ip >/dev/null 2>&1
if [ $? -ne 0 ]
then
echo "nrpe:$nagios_server_ip" >> /etc/hosts.allow
fi

#modify nrpe.cfg
cat /etc/nagios/nrpe.cfg|grep allowed_hosts|grep $nagios_server_ip > /dev/null 2>&1
if [ $? = 0 ]
then
#sed -i "s/^allowed_hosts.*$/$src,$nagios_server_ip/g" /etc/nagios/nrpe.cfg
echo "$nagios_server_ip in allow_list"
else
src=`cat /etc/nagios/nrpe.cfg|grep allowed_hosts`
sed -i "s/^allowed_hosts.*$/$src,$nagios_server_ip/g" /etc/nagios/nrpe.cfg
#sed -i "s/^allowed_hosts.*$/allowed_hosts=127.0.0.1,$nagios_server_ip/g" /etc/nagios/nrpe.cfg
fi


chmod +x /usr/sbin/nrpe
#start nrpe daemon
pkill nrpe
/usr/sbin/nrpe -c /etc/nagios/nrpe.cfg -d
sleep 3
#modify the user auth 
chmod 777 /etc/sudoers
sed -i '$a nagios ALL=(ALL) NOPASSWD:ALL' /etc/sudoers
sed -i '$a nrpe ALL=(ALL) NOPASSWD:ALL' /etc/sudoers
sed -i "s/^Defaults.*requiretty/#Defaults requiretty/" /etc/sudoers
chmod 440 /etc/sudoers
chmod 0440 /etc/sudoers.d/nrpe
check_port=`netstat -an |grep 5666|grep 0.0.0.0|cut -d" " -f1`
if [ ! -n "$check_port" ];
then
   echo "NRPE port check failed...return"
   code=1
else
   echo "NRPE port check success,continue..."
   code=0
fi

#ps -ef|grep monitor_sdoss.sh |grep -v grep >/dev/null 2>&1
#if [ $? -ne 0 ]
#then
#    cd /usr/lib64/nagios/plugins
#    ./monitor_sdoss.sh >/dev/null 2>&1 &
#    cd -
#else
#   kill `ps -ef|grep monitor_sdoss.sh|grep -v grep|awk '{print $2}'` 
#    cd /usr/lib64/nagios/plugins
#    ./monitor_sdoss.sh >/dev/null 2>&1 &
#    cd -
#fi
service nrpe restart
service sdoss-monitor restart 
chkconfig nrpe on
chkconfig sdoss-monitor on
service iptables stop

if [ $code -eq 0 ]
then
echo "sdoss monitor client installation succeed."
else
echo "sdoss monitor client installation failed."
fi
fi

########################################################
####                                                ####
####          Install Monitor-UI Server             ####
####                                                ####
########################################################


if [ $type = server ]
then
code=0
chmod +x sdoss-monitor-server/python/*
eth=$2
useradd nagios
rpm -ivh sdoss-monitor-server/deps-rhel63/*.rpm --force --nodeps
if [ $? != 0 ];then
code=1
fi
#yum localinstall sdoss-monitor-server/rpms-rhel63/*.rpm -y
rpm -ivh sdoss-monitor-server/rpms-rhel63/*.rpm --force --nodeps
if [ $? != 0 ];then
code=1
fi

yum install pexpect -y
if [ $? -ne 0 ]
then
code=1
fi
sed -i "s/use_authentication=1/use_authentication=0/" /etc/nagios/cgi.cfg
chmod 777 /etc/sudoers
sed -i '$a nagios ALL=(ALL) NOPASSWD:ALL' /etc/sudoers
sed -i '$a nrpe ALL=(ALL) NOPASSWD:ALL' /etc/sudoers
sed -i "s/^Defaults.*requiretty/#Defaults requiretty/" /etc/sudoers
chmod 440 /etc/sudoers 
#modify pnpurl
#example:'url: https://nagiosadmin:nagiosadmin@10.27.38.30/pnp4nagios'
#local_ipaddr=`ifconfig  | grep 'inet addr:'| grep -v '127.0.0.1' | cut -d: -f2 | awk '{ print $1}'`
local_ipaddr=`ifconfig -a|grep $eth -A 1|grep -v $eth|awk '{print $2}'|awk -F: '{print $2}'`
echo $local_ipaddr
sed -i "s^url: http://localhost/pnp4nagios^url: https://nagiosadmin:nagiosadmin@$local_ipaddr/pnp4nagios^g" /etc/monitoring-ui-plugin/monitoring-ui.yml
sed -i "s/source: ido/source: mk-livestatus/" /etc/monitoring-ui-plugin/monitoring-ui.yml
sed -i "s.#  socket: /var/spool/icinga/rw/live.  socket: /var/spool/nagios/cmd/live.g" /etc/monitoring-ui-plugin/monitoring-ui.yml
#Make sure the http/s ports are accessible
#iptables -I INPUT 4 -p tcp --dport 443 -m state --state NEW,ESTABLISHED -j ACCEPT
#service iptables save
#service iptables restart
#modify nagios-gluster python scripts in /usr/lib64/nagios/plugins/gluster/ directory
#brick and host uuid is not wright


#round_check
ps -ef|grep get_round.py|grep -v grep >/dev/null 2>&1
if [ $? -ne 0 ]
then
   nohup /usr/lib64/nagios/plugins/get_round.py & 
fi

#unalias cp
\cp -rf sdoss-monitor-server/python/* /usr/lib64/nagios/plugins/
\cp -rf sdoss-monitor-server/php/*.php /usr/share/nagios/html/pnp4nagios/templates.dist/
\cp -rf sdoss-monitor-server/nagioscfg/* /etc/nagios/
\cp -rf sdoss-monitor-server/css/common.css /usr/share/nagios/html/stylesheets/
#cp -f sdoss-monitor-server/js/*.cfg /usr/share/monitoring-ui-plugin/javascript/
alias cp='cp -i'
chmod +x /usr/lib64/nagios/plugins/*.py
#shutoff setenforce
setenforce 0
chmod 0440 /etc/sudoers.d/nagios
yum install openssl-devel -y
yum install mod_ssl -y

cat /etc/resolv.conf|grep -E "192.168.131.17|192.168.131.18" >/dev/null 2>&1
if [ $? -ne 0 ]
then
echo "nameserver 192.168.131.17">> /etc/resolv.conf 
echo "nameserver 192.168.131.18">> /etc/resolv.conf 
fi
#sed -i -e 's/1440/1/g' /etc/nagios/gluster/gluster-host-services.cfg
#Run configuration script to detect the nodes/volumes in the gluster trusted pool and to create Nagios services for these
service httpd start
chkconfig httpd on
service nsca restart
service nagios restart
chkconfig nagios on
chkconfig nsca on
service iptables stop
if [ $code -eq 0 ]
then
    echo "install server succeed."
else
    echo "install server failed."
fi
fi


