#!/bin/sh


port=8000
#if [ $# -eq 1 ]
#then
#port=$1
#else
#cat <<EOF
#Usage:
#start_server.sh port
#EOF
#exit 1
#fi

python -m CGIHTTPServer $port
