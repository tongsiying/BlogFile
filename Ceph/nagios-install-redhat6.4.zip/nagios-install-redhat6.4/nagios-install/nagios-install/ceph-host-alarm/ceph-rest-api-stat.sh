#!/bin/bash

check_process=`ps ajx |grep "ceph-rest-api -n client.admin"|grep -v grep`
#echo $check_process
if [ -z "$check_process" ];then
	echo "ceph-rest-api process is down!"
	exit 2
fi

check_process=`ps ajx |grep "ceph-rest-api -n client.admin"|grep -v grep|awk '{print $7}'`
if [[ "$check_process" == "Z" ]];then
	echo "ceph-rest-api process is zombie status!"
	exit 2
fi

echo "ceph-rest-api process is OK."
exit 0
