#!/usr/bin/python
from __future__ import division
import cephcommon

ceph_rest_api_url = "http://10.109.140.1:5000/api/v0.1"
osd_max_num = 24

def getCephOsdStatus(url):
	res_data = cephcommon.getHttpRes(url)
	dictinfo = cephcommon.convertJSONtoDICT(res_data)

	res=[]
	osds_status = dictinfo["output"]["osds"]

	for i in range(0, osd_max_num):
		cur_osd_status = osds_status[i]
		osd_up = cur_osd_status["up"]
		osd_in = cur_osd_status["in"]
		if osd_up != 1 or osd_in != 1:
			if osd_up != 1:
				isup = "down"
			else:
				isup = "in"
			if osd_in != 1:
				isin = "out"
			else:
				isin = "in"
			tmp = [i, isup, isin]
			res.append(tmp)

	return res

if __name__=='__main__':
	try:
		res = getCephOsdStatus(ceph_rest_api_url + '/osd/dump')
		print "ceph osd down/out list %r" % res

		ret_code = 0
		if len(res) != 0:
			ret_code = 2
		exit(ret_code)
	except Exception as e:
		print e
		exit(2)

