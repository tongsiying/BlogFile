#!/usr/bin/python
import cephcommon

#config info
ceph_rest_api_url = "http://10.109.140.1:5000/api/v0.1"

def getCephPgStat(url):
	res_data = cephcommon.getHttpRes(url)
	dictinfo = cephcommon.convertJSONtoDICT(res_data)

	res = []
	pg_stats = dictinfo["output"]["num_pg_by_state"]

	for m in range(len(pg_stats)):
		#print pg_stats[m]
		#print cmp(pg_stats[m]["name"], "active+clean")
		if cmp(pg_stats[m]["name"], "active+clean") != 0 and cmp(pg_stats[m]["name"], "active+clean+scrubbing") != 0:
			res.append(pg_stats[m])

	return res

if __name__=='__main__':
	try:
		res = getCephPgStat(ceph_rest_api_url + '/pg/stat')
		#print "ceph pg stat: %r" % res

		ret_code = 0
		if len(res) != 0:
			ret_code = 2
			print "ceph pg stat: %r" % res
		else:
			print "ceph pg stat: active+clean"
		exit(ret_code)
	except Exception as e:
		print e
		exit(2)
