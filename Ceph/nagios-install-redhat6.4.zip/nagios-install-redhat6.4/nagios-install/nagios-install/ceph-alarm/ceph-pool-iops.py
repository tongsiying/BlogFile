#!/usr/bin/python
import cephcommon

#config info
ceph_rest_api_url = "http://10.109.140.1:5000/api/v0.1"
pool_bytes_limit = 1000000000
pool_recovery_bytes_limit = 1000000000

def getCephPoolIops(url):
	res_data = cephcommon.getHttpRes(url)
	dictinfo = cephcommon.convertJSONtoDICT(res_data)

	pool_iops =  dictinfo["output"]
	res = []
	res1 = []

	for i in range(0, len(pool_iops)):
		client_io_rate = pool_iops[i]["client_io_rate"]
		recovery_io_rate = pool_iops[i]["recovery"]

		if 0 != len(client_io_rate):
			#print pool_iops[i]['pool_name']
			#print client_io_rate
			tmp_read_bytes_sec = 0
			tmp_write_bytes_sec = 0
			if 'read_bytes_sec' in client_io_rate.keys():
				tmp_read_bytes_sec = client_io_rate['read_bytes_sec']
			if 'write_bytes_sec' in client_io_rate.keys():
				tmp_write_bytes_sec = client_io_rate['write_bytes_sec']
			sum  = tmp_read_bytes_sec + tmp_write_bytes_sec
			#print sum
			if sum > pool_bytes_limit:
				res.append(pool_iops[i]['pool_name'])
				res.append(client_io_rate)

			res1.append(pool_iops[i]['pool_name'])
			res1.append(client_io_rate)
		#if 0 != len(recovery_io_rate):
		#	if recovery_io_rate['read_bytes_sec']+recovery_io_rate['write_bytes_sec'] > pool_recovery_bytes_limit:
		#		res.append(pool_iops[i]['pool_name'])
		#		res.append(recovery_io_rate)

	return res,res1	

if __name__=='__main__':
	try:
		res,res1 = getCephPoolIops(ceph_rest_api_url + '/osd/pool/stats')
		#print "rbd pool iops: %r" % res

		ret_code = 0
		if len(res) != 0:
			ret_code = 2
			print "rbd pool iops: %r" % res
			exit(ret_code)
		else:
			print "rbd pool iops: %r" % res1
			exit(ret_code)
	except Exception as e:
		#print "jacken"
		print e
		exit(2)


