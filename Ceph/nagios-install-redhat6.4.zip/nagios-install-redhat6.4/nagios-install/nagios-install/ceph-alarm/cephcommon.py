#!/usr/bin/python
#from __future__ import division
import urllib
import urllib2
import json

def currentFrame():
	"""Return the frame object for the caller's stack frame."""
	try:
		raise Exception
	except:
		return sys.exc_traceback.tb_frame.f_back

def getHttpRes(url):
	"""get http json string result from ceph rest wsgi url"""
	req = urllib2.Request(url)
	#print req
	req.add_header('Accept', 'application/json')
	#print "----------------------------------"
	try:
		res_data = urllib2.urlopen(req)
		res = res_data.read()
		return res
	except Exception, e:
		currentFrame()
		print e

def convertJSONtoDICT(res_data):
	"""clear enough for itself's function name~~~"""
	res_data = json.loads(res_data)
	#print res_data
	return res_data

#def getCephClusterDf(url):
#	res_data = getHttpRes(url)
#	dictinfo = convertJSONtoDICT(res_data)
#	total_used_bytes = dictinfo["output"]["stats"]["total_used_bytes"]
#	total_bytes = dictinfo["output"]["stats"]["total_bytes"]
#	res = total_used_bytes/total_bytes
#	return res

#ceph_rest_api_url = "http://10.37.2.16:5000/api/v0.1"

#if __name__=='__main__':	
#	cephClusterDiskUsage = getCephClusterDf(ceph_rest_api_url + '/df')
#	print "ceph cluster disk usage %r" % cephClusterDiskUsage

