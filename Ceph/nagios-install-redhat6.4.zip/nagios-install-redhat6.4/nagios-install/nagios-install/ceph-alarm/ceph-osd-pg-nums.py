#!/usr/bin/python
from __future__ import division
import cephcommon

#config info
ceph_rest_api_url = "http://10.109.140.1:5000/api/v0.1"
max_ratio = 1.1
min_ratio = 0.9

def getCephOsdPgNums(url):
	res_data = cephcommon.getHttpRes(url)
	dictinfo = cephcommon.convertJSONtoDICT(res_data)

	res = []
	max_num = dictinfo["output"]["min_osd_pgs"]
	min_num = dictinfo["output"]["max_osd_pgs"]
	avg_num = dictinfo["output"]["avg_pgs"]
	
	#print max_num/avg_num
	if max_num/avg_num > max_ratio:
		res.append(max_num/avg_num)

	#print min_num/avg_num
	if min_num/avg_num < min_ratio:
		res.append(min_num/avg_num)

	print "max ratio:%.3f, min ratio:%.3f" % (max_num/avg_num ,min_num/avg_num)
	return res

if __name__=='__main__':
	try:
		res = getCephOsdPgNums(ceph_rest_api_url + '/osd/utilization')
		print "ceph pg num per osd exceed limit: %r" % res

		ret_code = 0
		if len(res) != 0:
			ret_code = 2
		exit(ret_code)
	except Exception as e:
		print e
		exit(2)

