#!/usr/bin/python
from __future__ import division
import cephcommon

#config info
ceph_rest_api_url = "http://10.109.140.1:5000/api/v0.1"
critical_limit = 0.85
warning_limit = 0.80

def getCephClusterDf(url):
	res_data = cephcommon.getHttpRes(url)
	dictinfo = cephcommon.convertJSONtoDICT(res_data)
	total_used_bytes = dictinfo["output"]["stats"]["total_used_bytes"]
	total_bytes = dictinfo["output"]["stats"]["total_bytes"]
	res = total_used_bytes/total_bytes
	return res

if __name__=='__main__':
	try:
		ret_code = 0
		cephClusterDiskUsage = getCephClusterDf(ceph_rest_api_url + '/df')
		print "ceph cluster disk usage: %.2f%%" % (cephClusterDiskUsage*100)
		if cephClusterDiskUsage > critical_limit:
			ret_code = 2
		if cephClusterDiskUsage > warning_limit:
			ret_code = 1
		exit(ret_code)
	except Exception as e:
		print e
		exit(2)

