#!/usr/bin/python
from __future__ import division
import os
import cephcommon

#config info
ceph_rest_api_url = "http://10.109.140.1:5000/api/v0.1"

def getCephMonLeader(url):
	res_data = cephcommon.getHttpRes(url)
	dictinfo = cephcommon.convertJSONtoDICT(res_data)

	res = []
	mon_leader = dictinfo["output"]["quorum_leader_name"];

	if os.path.isfile('./cephmonleader.txt'):
		file_object = open('./cephmonleader.txt','rb+')
	else:
		os.mknod('./cephmonleader.txt')
		file_object = open('./cephmonleader.txt','rb+')

	try:
		last_mon_leader = file_object.read()
		#print "last mon leader %r" % last_mon_leader
		if last_mon_leader != mon_leader:
			res = [last_mon_leader, mon_leader]
			file_object.seek(0, 0)
			file_object.truncate()
			file_object.write(mon_leader);
		else:
			res = []
	finally:
		file_object.close()

	return res

if __name__=='__main__':
	try:
		res = getCephMonLeader(ceph_rest_api_url + '/quorum_status')
		print "ceph mon leaders changes: %r" % res
		ret_code = 0
		if len(res) != 0:
			ret_code = 1
		exit(ret_code)
	except Exception as e:
		print e 
		exit(2)

