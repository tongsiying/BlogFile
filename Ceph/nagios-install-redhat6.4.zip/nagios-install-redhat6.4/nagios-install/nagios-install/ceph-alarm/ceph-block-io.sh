#!/bin/bash

res=`curl -i http://10.109.140.1:5000/api/v0.1/status 2>&1| grep "requests are blocked"`

#echo $res

if [ -z "$res" ];
then
	echo "no blocked IO"
	exit 0
fi

echo $res
exit 2
