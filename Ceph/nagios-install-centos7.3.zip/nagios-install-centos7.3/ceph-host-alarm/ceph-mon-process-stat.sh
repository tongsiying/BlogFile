#!/bin/bash
exit_code=0

#config info
MONLIST="ceph2"

for i in $MONLIST;
do
        processtat=`ps -ef|grep "ceph-mon -i $i"|grep -v grep`
        if [ -z "$processtat" ];then
                exit_code=2
                downlist=${downlist}"mon."${i}","
        fi

	processtat=`ps -ef|grep "ceph-mon -i $i"|grep -v grep|awk '{print $7}'`
        if [[ "$processtat" == "Z"  ]];then
                exit_code=2
                zombielist=${zombielist}"mon."${i}","
        fi
done

if [ $exit_code -eq 0 ];then
        echo "ceph mon processes is OK."
        exit $exit_code
else
        echo "ceph mon down list:$downlist zombie list:$zombielist"
        exit $exit_code
fi
