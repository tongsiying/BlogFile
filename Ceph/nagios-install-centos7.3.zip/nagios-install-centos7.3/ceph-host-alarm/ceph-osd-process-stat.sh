#!/bin/bash
exit_code=0

#config info
OSDLIST="8 9 10 11 12 13 14 15"

for i in $OSDLIST;
do
	processtat=`ps ajx|grep "ceph-osd -i $i"|grep -v grep`
	if [ -z "$processtat" ];then
		exit_code=2
		downlist=${downlist}"osd."${i}","
	fi

	processtat=`ps ajx|grep "ceph-osd -i $i"|grep -v grep|awk '{print $7}'`
	if [[ "$processtat" == "Z"  ]];then
		exit_code=2
		zombielist=${zombielist}"osd."${i}","
	fi
done

if [ $exit_code -eq 0 ];then
	echo "ceph osd processes is OK."
	exit $exit_code
else
	echo "ceph osd down list:$downlist zombie list:$zombielist"
	exit $exit_code
fi
