#!/usr/bin/python
# -*- coding: utf-8 -*- 


import commands
import argparse
import ConfigParser

ceph_service_type = ['ceph-cluster-diskusage','ceph-osd-stat','ceph-pg-stat','ceph-pool-iops','ceph-osd-pg-nums','ceph-mon-stat','ceph-mon-leader-change',\
                     'ceph-mon-process-stat','ceph-osd-process-stat','ceph-rest-api-stat',\
                     'check_memory','check_disk_and_inode','check_cpu_multicore','check_interfaces','disk_performance','check_host_alive']

def parse_input():
    parser = argparse.ArgumentParser()
    parser.add_argument("-t", "--type", action="store",
                        required=False,
                        help="Monitor Type")
    parser.add_argument("-i", "--ip", action="store",
                        required=True,
                        help="Host IP")
    parser.add_argument("-m", "--msg", action="store",
                        required=True,
                        help="Monitor message")
    parser.add_argument("-c", "--cluster", action="store",
                        required=False,
                        help="cluster name")
    parser.add_argument("-s", "--state", action="store",
                        required=False,
                        help="state")
    parser.add_argument("-H", "--hstate", action="store",
                        required=False,
                        help="host state")
    args = parser.parse_args()
    return args

def get_receiver():
    file='/usr/lib64/nagios/plugins/ceph/.receiver'
    config = ConfigParser.ConfigParser()
    config.read(file)
    return config.get(args.cluster,'receiver')


def send_sms(msg, host):
    receiver=get_receiver()
    #receiver='13092212'
    if args.type is None:
       args.type=" "
    send_msg=""
    system="CEPH DISTRIBUTED SYSTEM"
    cmd='cat /usr/lib64/nagios/plugins/ceph/host.txt|grep ' + host + ''' |awk '{print $1'} '''
    
    out=commands.getstatusoutput(cmd)
    system=out[1]
    if system == "" or system == "\n":
       system="CEPH DISTRIBUTED SYSTEM"

    if msg.startswith("CHECK_NRPE: Socket timeout after") or msg.startswith("CRITICAL: Check request failed") or msg.__contains__("Return code of 255 is out of bounds"):
       return
       
    if args.type in ceph_service_type:
       send_msg = system + ' ' + host + ' ' + msg
       print "---------------------------------"
       print send_msg
       print "---------------------------------"

    if args.state == '0' and args.type in ceph_service_type:
       send_msg = '[ALARM RECOVERY] ' + send_msg

    cmd = '''curl --header "Content-Type:text/html;charset=GBK" --data '{"alarmSource":"monitor","alarmContent":"''' + send_msg + '''","sendway":"phone","alarmReceiver":"''' + receiver + '''"}' http://monitor.cnsuning.com/monitor-alarmcenter/alarmService/alarmNotice'''

    print cmd
    #cmd = ''' curl --header "Content-Type:text/html;charset=GBK" --data '{"alarmSource":"monitor","alarmContent":" ''' + send_msg + ''' ","sendway":"phone","alarmReceiver":"''' + receiver + '''"}' http://10.19.250.191:9091/monitor-portal/monitor-alarmcenter/alarmService/alarmNotice '''
    out=commands.getstatusoutput(cmd) 
    if out[0] != 0:
       print "send sms failed."
       exit(2)
    

if __name__ == '__main__':
   try:
    args=parse_input()
    send_sms(args.msg,args.ip)
   except Exception,e:
    print e
    exit(1)
