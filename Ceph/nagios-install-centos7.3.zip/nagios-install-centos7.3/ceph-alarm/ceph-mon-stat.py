#!/usr/bin/python
from __future__ import division
import cephcommon

#config info
ceph_rest_api_url = "http://10.109.140.1:5000/api/v0.1"
mon_max_num = 3
mons_list = ['ceph1', 'ceph2', 'ceph3']

def getCephMonStatus(url):
	res_data = cephcommon.getHttpRes(url)
	dictinfo = cephcommon.convertJSONtoDICT(res_data)

	res = []
	mon_status = dictinfo["output"]["quorum_names"];

	cur_mon_num = len(mon_status);
	for i in range(0, mon_max_num):
		mon_list_element = mons_list[i]
		#print type(mon_list_element)
		if mon_list_element not in mon_status:
			res.append(mon_list_element)
	return res

if __name__=='__main__':
	try:
		res = getCephMonStatus(ceph_rest_api_url + '/quorum_status')
		print "ceph mon down status %r" % res

		ret_code = 0
		if len(res) != 0:
			ret_code = 2
		exit(ret_code)
	except Exception as e:
		print e
		exit(2)
