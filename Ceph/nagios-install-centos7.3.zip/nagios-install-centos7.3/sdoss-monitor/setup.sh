#!/bin/sh

if [ $# -ne 3 ]
then
cat <<EOF
usage:
setup.sh type install_ip monitor_server
EOF
exit 1
fi

type=$1
install_ip=$2
monitor_server=$3

function install_client()
{
wget http://$install_ip:8000/sdoss-monitor-client.tar.gz
wget http://$install_ip:8000/sdoss-monitor-install.sh
wget http://$install_ip:8000/round_check.tar.gz

tar zxvf sdoss-monitor-client.tar.gz
chmod -R 777 sdoss-monitor-client
chmod +x sdoss-monitor-install.sh
./sdoss-monitor-install.sh client $monitor_server

}

function install_server()
{
wget http://$install_ip:8000/sdoss-monitor-server.tar.gz
wget http://$install_ip:8000/sdoss-monitor-install.sh

tar zxvf sdoss-monitor-server.tar.gz
chmod -R 777 sdoss-monitor-server
chmod +x sdoss-monitor-install.sh
eth=`ifconfig -a|grep $monitor_server -B 2|grep -v $monitor_server|awk '{print $1}'`
./sdoss-monitor-install.sh server $eth
}


if [ $type = "server" ]
then
install_server
exit 0
fi

if [ $type = "client" ]
then
install_client
exit 0
fi
