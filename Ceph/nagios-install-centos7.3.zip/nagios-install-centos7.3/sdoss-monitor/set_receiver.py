#!/usr/bin/python


import commands
import argparse
import ConfigParser

file='/usr/lib64/nagios/plugins/.receiver'
config = ConfigParser.ConfigParser()
config.read(file)
def parse_input():
    parser = argparse.ArgumentParser()
    parser.add_argument("-c", "--cluster", action="store",
                        required=True,
                        help="sdoss cluster name")    
    parser.add_argument("-s", "--receiver", action="store",
                        required=False,
                        help="Set sms receiver list")
    parser.add_argument('-l', '--list', action='store_true', dest='list',default='False',
                        help="List the receiver list")
    parser.add_argument("-a", "--add", action="store",
                        required=False,
                        help="Add a receiver list")
    args = parser.parse_args()
    return args

def get_sections():
    config.read(file)
    return config.sections() 

def set_value(section,option,value):
    config.set(section,option,value)
    config.write(open(file,"w"))

def add_section(section):
    config.add_section(section)
    config.write(open(file,"w"))

def get_value(section,option):
    config.read(file)
    return config.get(section,option)
   
if __name__ == '__main__':
   try:
      args=parse_input()
      if args.list == True:
          r=get_value(args.cluster,'receiver')
          print r
          exit(0)
      elif args.receiver is not None:
          s=get_sections()
          if s is None or s == []:
             add_section(args.cluster)
          elif args.cluster  not in s: 
             add_section(args.cluster)
          set_value(args.cluster,'receiver',args.receiver)
          exit(0)
      elif args.add is not None:
          l=get_value(args.cluster,'receiver')
          if l:
             l=l+','+args.add
          else:
             l=args.add
          set_value(args.cluster,'receiver',l)
   except Exception,e:
      exit(1)
