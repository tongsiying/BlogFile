#!/usr/bin/python


import commands
import argparse
import json

NGINX_MAX=8

true=True

def parse_input():
    parser = argparse.ArgumentParser()
    parser.add_argument("-t", "--type", action="store",
                        required=True,
                        help="Monitor Weed Type.\n filer , volume")
    parser.add_argument("-i", "--ip", action="store",
                        required=True,
                        help="Host IP")
    parser.add_argument("-c", "--critical", action="store",
                        required=True,type=int,
                        help="Request Threshold")
#    parser.add_argument("-c", "--critical", action="store",
#                        required=True, type=int,
#                        help="Critical threshold in percentage")
#    sadf.add_common_args(parser)
    args = parser.parse_args()
    return args

def get_request(s):
    data=json.dumps(s)
    data=eval(eval(data))
    d=data['RequestStatic']['DeleteRequests']
    r=data['RequestStatic']['ReadRequests']
    q=data['RequestStatic']['QueryRequests']
    w=data['RequestStatic']['WriteReuests']
    return d['Requeststodo'] , r['Requeststodo'] , q['Requeststodo'] , w['Requeststodo']

if __name__=='__main__':
  try:
    args=parse_input()
    code=0
    msg=''
    cmd='/usr/lib64/nagios/plugins/check_weed_status.py -t ' + args.type + '  -i ' + args.ip
    re=commands.getstatusoutput(cmd)
    if re[0] == 0:
       msg="OK. check request OK."# + re[1]
    else:
       code=2 
       msg="CRITICAL: Check request failed." 
       print msg
       exit(code)
    x=(d,r,q,w)=get_request(re[1])
    status={"delete":{"requests":d,"status":"OK"},"read":{"requests":r,"status":"OK"},"query":{"requests":q,"status":"OK"},"write":{"requests":w,"status":"OK"}}
    if d >= args.critical:
       status["delete"]["status"] = "CRITICAL"
       code=2
    if r >= args.critical:
       status["read"]["status"] = "CRITICAL"
       code=2
    if q >= args.critical:
       status["query"]["status"] = "CRITICAL"
       code=2
    if w >= args.critical:
       status["write"]["status"] = "CRITICAL"
       code=2
    msg="Sdoss Request Sumary: "
    for v in status.keys():
         msg += v + "[request:" + str(status[v]["requests"]) + " status:" + status[v]["status"] + "] "
    msg +="|num=4 "
    for v in status.keys():
        msg += v + "=" + str(status[v]["requests"]) + ";" + str(args.critical) + ";" + str(args.critical) + " "


    #msg += "|requests=" + str(request) + ";" + str(args.critical)+";" + str(args.critical)+";0;" + str(request)
    print msg
    exit(code)
  except Exception as e:    
    print "CRITICAL: Exception:" + str(e)
    exit(2)
    

   
