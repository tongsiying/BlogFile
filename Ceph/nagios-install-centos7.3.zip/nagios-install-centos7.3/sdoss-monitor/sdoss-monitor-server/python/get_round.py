#!/usr/bin/python
# -*- coding: utf-8 -*- 

import commands
import time
import os
from multiprocessing import Process,Queue
import thread  


INFO=2
WARN=1

MSG_LEN=512
BASE_DIR='/usr/lib64/nagios/plugins/'


typelist=[
"Filer UPLOAD",
"Filer DOWNLOAD",
"Filer DELETE",
"Master UPLOAD",
"Master DOWNLOAD",
"Volume UPLOAD",
"Volume DOWNLOAD",
"Volume DELETE",
"Volume FIX",
"Volume VACUUM"
]
codelist=[
["1000","1001","1002","1003","1004","1005","1006"],
["1100","1101","1102","1103"],
["1200","1201"],
["2000","2001"],
["2100"],
["3000","3001","3002","3003"],
["3100","3101","3102","3103","3104"],
["3200","3201"],
["3300","3301","3302","3303","3304"],
["3400","3401","3402","3403","3404","3405","3406","3407"]
]
sys_list=[
"sdoss_ips",
"sdosspool_ips",
"dianpu_ips",
"shangpu_ips"
]


ips_all={
"sdoss_ips":[],
"sdosspool_ips":[],
"dianpu_ips":[],
"shangpu_ips":[]
}

#tips=["192.168.36.37","192.168.36.35"]
a={}
b={}
c={}
d={}
e={}


def GetIps():
    ips=[]
    if os.path.exists("/etc/nagios/conf.d/weed-sdoss.cfg"):
       cmd=''' cat /etc/nagios/conf.d/weed-sdoss.cfg |grep host_name|grep -E '\.'|awk '{print $2}' '''
       r=commands.getstatusoutput(cmd)
       if r[0] == 0:
          ips=r[1].split()
          ips_all["sdoss_ips"]=list(set(ips))

    if os.path.exists("/etc/nagios/conf.d/weed-sdosspool.cfg"):
       cmd=''' cat /etc/nagios/conf.d/weed-sdosspool.cfg |grep host_name|grep -E '\.'|awk '{print $2}' '''
       r=commands.getstatusoutput(cmd)
       if r[0] == 0:
          ips=r[1].split()
          ips_all["sdosspool_ips"]=list(set(ips))

    if os.path.exists("/etc/nagios/conf.d/weed-DianPuMoBan.cfg"):
       cmd=''' cat /etc/nagios/conf.d/weed-DianPuMoBan.cfg |grep host_name|grep -E '\.'|awk '{print $2}' '''
       r=commands.getstatusoutput(cmd)
       if r[0] == 0:
          ips=r[1].split()
          ips_all["dianpu_ips"]=list(set(ips))

    if os.path.exists("/etc/nagios/conf.d/weed-ShangHuDianDan.cfg"):
       cmd=''' cat /etc/nagios/conf.d/weed-ShangHuDianDan.cfg |grep host_name|grep -E '\.'|awk '{print $2}' '''
       r=commands.getstatusoutput(cmd)
       if r[0] == 0:
          ips=r[1].split()
          ips_all["shangpu_ips"]=list(set(ips))

def InitE():
    global e
    e={}
    file= BASE_DIR + 'msg.csv'
    f=open(file)
    lines=f.readlines()
    f.close()

    for line in lines:
         l=line.split(",")
         code=l[2].strip()
         level=l[3].strip()
         if int(level) == INFO:
             e[code]={"count":0,"order":-1,"level":INFO}

#receiver="13092212"
receiver='13071518,14042368,13121242,13092212,13073401,14041605,14031171,14042042,14030870,14042402,13071583,10073586'
def StatInfo():
    global e
    try:
       #while True:
          msg="��Ѳ�졿\\n ���ʱ�䣺һ���� \\n"
          msg1="" 
          for i in e:
             if e[i]["count"] != 0:
                msg1 += "�����룺" + i + "(" + get_des(int(i))  + ")\\n" + "����������" + str(e[i]["count"]) + "\\n"
           #cmd = ''' curl --header "Content-Type:text/html;charset=GBK" --data @''' + msg_file + ''' http://monitor.cnsuning.com/monitor-alarmcenter/alarmService/alarmNotice '''
          if msg1 != "": 
              msg += msg1
              cmd = ''' curl --header "Content-Type:text/html;charset=GBK" --data '{"alarmSource":"monitor","alarmContent":" ''' + msg + ''' ","sendway":"phone","alarmReceiver":"''' + receiver + '''"}' http://monitor.cnsuning.com/monitor-alarmcenter/alarmService/alarmNotice '''
              out=commands.getstatusoutput(cmd)
              if out[0] != 0:
                  print "send msg failed."
          InitE()
    except Exception,ee:
           print ee
           exit(1)


def Init(ips):
    global a
    global b
    global c
    global d
    
    a={}
    b={}
    c={}
    d={}
    file= BASE_DIR + 'msg.csv'
    f=open(file)
    lines=f.readlines()
    f.close()

    for line in lines:
         l=line.split(",")
         code=l[2].strip()
         c[code]={}
         c[code]={"count":0,"order":-1,"level":WARN}
         level=l[3].strip()
         #if int(level) == INFO:
         c[code]["level"] = WARN 
         if int(level) == INFO:
             c[code]["level"] = INFO 

    for ip in ips:
       d[ip]={}
       a[ip]={}
       for line in lines:
          line=line.split(",")
          line=line[2].strip()
          a[ip][line]={}
          a[ip][line]["count"]=0
       for t in typelist:
          d[ip][t]={}
          d[ip][t]["count"] = 0
          d[ip][t]["order"] = -1

    for i in typelist:
       b[i]={"count":0,"top3":[0,0,0],"top3ips":["","",""]}

def get_host_system(i):
    if i == 0:
       return "����ͼƬϵͳ��"
    if i == 1:
       return "SDOSS�洢��Դ�أ�"
    if i == 2:
       return "����ģ�壺"
    if i == 3:
       return "���̶���: "


def GetValue(ips):
    global e
    for ip in ips:
       cmd='/usr/lib64/nagios/plugins/check_nrpe -H %s -c check_round' %(ip)
       r=commands.getstatusoutput(cmd)
       if r[0] != 0:
           continue
       if r[1]== "none" :
           continue
       r=r[1].split()
       l=len(r)
       for i in range(l):
            if i % 3 != 1:
               continue
            if c[r[i]]["level"] == INFO:
               e[r[i]]["count"] += int(r[i+1])
               continue
            a[ip][r[i]]["count"] = int(r[i+1])

            c[r[i]]["count"] += int(r[i+1])
            for j in range(len(codelist)):
                if r[i] in codelist[j]:
                   d[ip][typelist[j]]["count"] += int(r[i+1])
                   d[ip][typelist[j]]["order"] = -1
                
    for t in typelist: 
        max_list=[0,0,0]
        for ip in ips:
             max_list.append(d[ip][t]["count"])
        max_list.sort()
        max_list.reverse()
        max_list=max_list[0:3]
        for ip in ips:
             for i in range(3):
                   if d[ip][t]["count"] == max_list[i] and d[ip][t]["count"] != 0:
                         d[ip][t]["order"] = i+1

def StatValue(ips):
    global e
    for i in range(len(typelist)):
        for ip in ips:
          tmp_l=codelist[i]
          for t in tmp_l:
              b[typelist[i]]["count"] += a[ip][t]["count"]
        
           

#def GetFile(ips):
#    for ip in ips:
#       cmd='/usr/lib64/nagios/plugins/check_nrpe -H %s -c round_sum' %(ip) 
#       r=commands.getstatusoutput(cmd)
#       if r[0] != 0:
#          continue
#       r=r[1].split()
#       typelen=len(typelist)
#       for i in range(typelen):
#            b[typelist[i]]["count"] += int(r[i])
#            if int(r[i]) != 0:
#              b[typelist[i]]["top3"].append(int(r[i]))
#              b[typelist[i]]["top3"].sort()
#              b[typelist[i]]["top3"].reverse()
#              b[typelist[i]]["top3"]=b[typelist[i]]["top3"][0:3]
#            for j in range(3):
#               if b[typelist[i]]["top3"][j] == int(r[i]) and int(r[i]) !=0 :
#                  b[typelist[i]]["top3ips"][j] += ip + " "
#
#       cmd='/usr/lib64/nagios/plugins/check_nrpe -H %s -c check_round' %(ip) 
#       r=commands.getstatusoutput(cmd)
#       if r[0] != 0:
#           continue
#       if r[1]== "none" :
#           continue
#       r=r[1].split()
#       l=len(r)
#       for i in range(l):
#            if i % 3 != 1:
#               continue
#            a[r[i]]["count"] = a[r[i]]["count"] + int(r[i+1])
#            a[r[i]]["top3"].append(int(r[i+1])) 
#            a[r[i]]["top3"].sort()
#            a[r[i]]["top3"].reverse()
#            a[r[i]]["top3"] = a[r[i]]["top3"][0:3]
#            for j in range(3):
#               if a[r[i]]["top3"][j] == int(r[i+1]) and int(r[i+1]) != 0:
#                 a[r[i]]["top3ips"][j] = a[r[i]]["top3ips"][j] + (r[i-1]+" ")
#

def get_top3(ips,t):
    tmp = []
    for ip in ips:
        if d[ip][t]["order"] == 1:
           tmp.append(ip)
    for ip in ips:
        if d[ip][t]["order"] == 2:
           tmp.append(ip)
    for ip in ips:
        if d[ip][t]["order"] == 3:
           tmp.append(ip)
    tmp.append("")
    tmp.append("")
    tmp.append("")
    tmp = tmp[0:3]
    s = ""
    for tt in tmp:
        if tt in ips and t != "":
           s += tt + "(" + str(d[tt][t]["count"]) + ");\\n"
    return s

def get_code_top3(i):

    tmp1=[]
    for x in codelist[i]:
       tmp1.append(c[x]["count"])  
    tmp1.append(0)
    tmp1.append(0)
    tmp1.append(0)
    tmp1.sort()
    tmp1=list(set(tmp1))
    tmp1.reverse()
    tmp1=tmp1[0:3]

    tmp2=[]
    for x in codelist[i]:
        for ii in range(len(tmp1)): 
           if c[x]["count"] == tmp1[ii] and c[x]["count"] != 0:
              c[x]["order"] = ii+1
    for x in codelist[i]:
        if c[x]["order"] == 1:
           tmp2.append([x,c[x]["count"]])
    for x in codelist[i]:
        if c[x]["order"] == 2:
           tmp2.append([x,c[x]["count"]])
    for x in codelist[i]:
        if c[x]["order"] == 3:
           tmp2.append([x,c[x]["count"]])
    tmp2.append([])
    tmp2.append([])
    tmp2.append([])
    tmp2=tmp2[0:3]   
    s=""
    for t in tmp2:
        if t != []:
           s += t[0] + "(" + str(t[1]) + ")" + "����������" + get_des(int(t[0])) + "\\n"
    return s
    

       

msg_file="sms_tosend.txt"

def write_msg_file(msg,receiver):
    t=''' {"alarmSource":"monitor","alarmContent":" ''' + msg + ''' ","sendway":"phone","alarmReceiver":"''' + receiver + '''"}' http://monitor.cnsuning.com/monitor-alarmcenter/alarmService/alarmNotice '''
    f=open(msg_file,'w+')
    f.write(t)
    f.close()
    
def get_code_des(i):
    if i==0:
       return "Filerд�ļ�����"
    if i==1:
       return "Filer���ļ�����"
    if i==2:
       return "Filerɾ���ļ�����"
    if i==3:
       return "Masterд�ļ�����"
    if i==4:
       return "Master���ļ�����"
    if i==5:
       return "Volumeд�ļ�����"
    if i==6:
       return "Volume���ļ�����"
    if i==7:
       return "Volumeɾ���ļ�����"
    if i==8:
       return "Volume�޸��ļ�����"
    if i==9:
       return "Volume������������"
    
 


def send_msg(ips,sys_index):
    head="��Ѳ�졿\\n" 
    msg=""
    #receiver='13073401'
    #receiver='13092212'
    #receiver='13071518,14042368,13121242,13092212,13073401,14041605,14031171,14042042,14030870,14042402,12120146,13071583,10073586'
    for i in range(len(typelist)):
       x=typelist[i]
       msg=""
       if b[x]["count"] != 0:
          system=get_host_system(sys_index)
          msg += "����ϵͳ��" + system + "\\n"
          msg += "ͳ��ʱ�䣺��ȥһСʱ��.\\n"
          msg += "�������ݣ�" + get_code_des(i)  + "\\n"
          msg += "����������" + str(b[x]["count"]) + "\\n"
          msg += "�豸TOP3:\\n"
          msg += get_top3(ips,x)
          msg += "������TOP3��\\n"
          msg += get_code_top3(i) 

          msg_all = head + msg
          write_msg_file(msg_all,receiver)
          #cmd = ''' curl --header "Content-Type:text/html;charset=GBK" --data '{"alarmSource":"monitor","alarmContent":" ''' + msg_all + ''' ","sendway":"phone","alarmReceiver":"''' + receiver + '''"}' http://monitor.cnsuning.com/monitor-alarmcenter/alarmService/alarmNotice '''
          cmd = ''' curl --header "Content-Type:text/html;charset=GBK" --data @''' + msg_file + ''' http://monitor.cnsuning.com/monitor-alarmcenter/alarmService/alarmNotice '''
          out=commands.getstatusoutput(cmd)
          if out[0] != 0:
             print "send msg failed."
    #for x in a:
    #   if a[x]["count"] != 0:
    #      #des=get_des(int(x))
    #      msg += "code: %s  :%d :" %(x,a[x]["count"])
    #      for i in range(3):
    #         if a[x]["top3"][i] != 0:
    #             msg += "<" + "%s(%d)," % (a[x]["top3ips"][i],a[x]["top3"][i]) + ">;"

    #if msg == "":
    #   return
    
    #receiver='13071518,14042368,13121242,13092212,13073401,14041605,14031171,14042042,14030870,14042402,12120146,13071583,10073586'
    #cmd = ''' curl --header "Content-Type:text/html;charset=GBK" --data '{"alarmSource":"monitor","alarmContent":" ''' + send_msg + ''' ","sendway":"phone","alarmReceiver":"''' + receiver + '''"}' http://monitor.cnsuning.com/monitor-alarmcenter/alarmService/alarmNotice '''
    #out=commands.getstatusoutput(cmd)
    #if out[0] != 0:
    #   print "send msg failed."

def get_des(code):
    cmd="cat " + BASE_DIR + "msg.csv |grep %d|awk -F',' '{print $2}'" %(code)
    r=commands.getstatusoutput(cmd)
    r=r[1]
    return str(r).strip().decode('string_escape')


SLEEP_SEC=3600

def Proc_stat1():
    global e
    InitE()
    count=0
    try: 
        GetIps()
        while True:
            count += 1
            time.sleep(SLEEP_SEC)
            for i in range(len(sys_list)):
               if ips_all[sys_list[i]] == []:
                  continue
               Init(ips_all[sys_list[i]])
               GetValue(ips_all[sys_list[i]])
               StatValue(ips_all[sys_list[i]])
               #GetFile()
               send_msg(ips_all[sys_list[i]],i)
            if count == 24:
               count = 0
               StatInfo()
    except Exception,ee:
      print ee
      exit(1)
    

if __name__ == '__main__':
    try:
        #p1 = Process(target=Proc_stat1,args=())
        #p2 = thread.start_new_thread(StatInfo,())  
        #p1.start()
        #p2.start()
        #p1.join()
        #p2.join()
        Proc_stat1()
    except Exception,ee:
      print ee 
      exit(1)
