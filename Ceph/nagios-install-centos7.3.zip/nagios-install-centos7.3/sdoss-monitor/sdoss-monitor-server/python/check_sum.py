#!/usr/bin/env python

import utils
import argparse

NRPE_PATH = "/usr/lib64/nagios/plugins/check_nrpe"

def parse_input():
    parser = argparse.ArgumentParser()
    parser.add_argument("-l", "--list", action="store",
                        required=True,type=str,
                        help="sdoss volume server list")
    parser.add_argument("-c", "--critical", action="store",
                        required=True,type=int,
                        help="critical threshold")
    parser.add_argument("-t", "--type", action="store",
                        required=True,type=str,
                        help="sum type")
    args = parser.parse_args()
    return args

def getNRPEBaseCommand(host, timeout=None):
    command = NRPE_PATH + " -H " + host
    if timeout is not None:
        command += " -t %s" % timeout
    command += " -c "
    return command

def execNRPECommand(command):
    status, output, err = utils.execCmd(command.split(), raw=True)
    return status, output


def getSum(host,type):
    cmd=getNRPEBaseCommand(host)
    if type=="200":
       cmd += "check_200tps"
    if type=="404":
       cmd += "check_404tps"
    if type=="304":
       cmd += "check_304tps"
    if type=="sum":
       cmd += "check_sum_tps"
    if type=="traffic":
       cmd += "check_traffic_stat"
    status,output=execNRPECommand(cmd)
    if status <= 2 and output.__contains__("|"):
       output=output.split("|")[1].split(";")[0].split("=")[1]
    else:
       output=0
    return output

    

if __name__ == '__main__':
   try:
      args=parse_input()
      #cmd=getNRPEBaseCommand("10.27.38.23")
      #cmd += "check_200tps"
      hosts=args.list.split(",")
      len=len(hosts)
      sum=0
      txt=''
      if args.type != 'traffic':
          for host in hosts:
             sum += float(getSum(host,args.type) )
          if sum > args.critical * len:
             msg =  "CRITICAL: Get sum " + args.type + " tps exceed threshold. return: " + str(sum)
             code = 2
          else:
             msg =  "OK: Get sum " + args.type + " tps OK. return: " + str(sum)
             code = 0
          perfData="|" + args.type + "tps=" + str(sum) + ";" + str(args.critical) + ";" + str(args.critical) + ";0;" + str(sum)
          msg += perfData
      else:
          for host in hosts:
             sum += float(getSum(host,args.type) )
          if sum > args.critical * len:
             msg =  "CRITICAL: Get sum traffic exceed threshold. return: " + str(sum)
             code = 2
          else:
             msg =  "OK: Get sum traffic OK. return: " + str(sum)
             code = 0
          perfData="|traffic=" + str(sum) + ";" + str(args.critical) + ";" + str(args.critical) + ";0;" + str(sum)
          msg += perfData
      print msg
      exit(code)
   except Exception as e:
      print e
      exit(2)
