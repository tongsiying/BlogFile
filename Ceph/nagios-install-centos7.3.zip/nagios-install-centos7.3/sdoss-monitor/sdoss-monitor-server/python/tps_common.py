#!/usr/bin/python
import json
import pickle
import time
import os
import fcntl
import commands

INTERNAL=1
PICKLE_DATA='/usr/lib64/nagios/plugins/.data'
def get_tps(type,ip,tps_type):
     t=time.time() 
     stat={}
     if not os.path.exists(PICKLE_DATA + ip + tps_type):
         stat=wrapper_tps(type,ip,tps_type)
         f=open(PICKLE_DATA + ip + tps_type,"w")
         fcntl.flock(f, fcntl.LOCK_EX)
         #obj={"time":time.time(),"data":stat,"type":type}
         dump_pickle_data(f,stat)
         fcntl.flock(f,fcntl.LOCK_UN)
         f.close()
         return stat
     else:
         f=open(PICKLE_DATA + ip + tps_type,"r")
         fcntl.flock(f, fcntl.LOCK_EX)
         obj=get_pickle_data(f)
         t=0.0
         t1=obj["post"]["time"]
         t2=obj["get"]["time"]
         if t1 > t2:
             t= t1
         else:
             t= t2
         fcntl.flock(f,fcntl.LOCK_UN)
         f.close()
         now=time.time()
         if now - t >= INTERNAL:
            stat=wrapper_tps(type,ip,tps_type)
            f=open(PICKLE_DATA + ip + tps_type,"w") 
            fcntl.flock(f, fcntl.LOCK_EX)
            dump_pickle_data(f,stat)
            fcntl.flock(f,fcntl.LOCK_UN)
            f.close()
         else:
            stat=obj
     return stat

def wrapper_tps(type,ip,tps_type):
       cmd='/usr/lib64/nagios/plugins/check_weed_status.py -t ' + tps_type + '  -i ' + ip
       re=commands.getstatusoutput(cmd)
       if re[0] != 0:
          code=2
          msg="CRITICAL: Check request failed."
          print msg
          exit(code)

       time.sleep(1)

       cmd='/usr/lib64/nagios/plugins/check_weed_status.py -t ' + tps_type + '  -i ' + ip
       re=commands.getstatusoutput(cmd)
       if re[0] != 0:
          code=2
          msg="CRITICAL: Check request failed."
          print msg
          exit(code)

       data=json.dumps(re[1])
       data=eval(eval(data))
       stat={"post":{"20X":{},"304":{},"3XX":{},"404":{},"4XX":{},"5XX":{},"traffic_20X":{},"sum":{},"time":0.0},
             "get":{"20X":{},"304":{},"3XX":{},"404":{},"4XX":{},"5XX":{},"traffic_20X":{},"sum":{},"time":0.0}
            }
       if tps_type == "tps":
          stat["get"]["20X"]["count"] = data['TpsStatic']['VolumeGet']['Tps_20X'] 
          stat["get"]["304"]["count"] = data['TpsStatic']['VolumeGet']['Tps_304'] 
          stat["get"]["3XX"]["count"] = data['TpsStatic']['VolumeGet']['Tps_3XX'] 
          stat["get"]["404"]["count"] = data['TpsStatic']['VolumeGet']['Tps_404'] 
          stat["get"]["4XX"]["count"] = data['TpsStatic']['VolumeGet']['Tps_4XX'] 
          stat["get"]["5XX"]["count"] = data['TpsStatic']['VolumeGet']['Tps_5XX'] 
          stat["get"]["traffic_20X"]["count"] = data['TpsStatic']['VolumeGet']['Traffic_20X'] 
          #stat["get"]["sum"]["count"] = sum(data['TpsStatic']['VolumeGet'].values()) / INTERNAL
          stat["get"]["sum"]["count"] = (stat["get"]["20X"]["count"] +
                                          stat["get"]["304"]["count"] +
                                          stat["get"]["3XX"]["count"] +
                                          stat["get"]["404"]["count"] +
                                          stat["get"]["4XX"]["count"] +
                                          stat["get"]["5XX"]["count"] )
          stat["get"]["time"]=time.time()
    #stat["traffic"] = data['TpsStatic']['VolumeGet']['Tps_5XX'] + data['TpsStatic']['VolumePost']['Tps_5XX']
       #elif type == "post":
          stat["post"]["20X"]["count"] = data['TpsStatic']['VolumePost']['Tps_20X']
          stat["post"]["304"]["count"] = data['TpsStatic']['VolumePost']['Tps_304'] 
          stat["post"]["3XX"]["count"] = data['TpsStatic']['VolumePost']['Tps_3XX'] 
          stat["post"]["404"]["count"] = data['TpsStatic']['VolumePost']['Tps_404'] 
          stat["post"]["4XX"]["count"] = data['TpsStatic']['VolumePost']['Tps_4XX'] 
          stat["post"]["5XX"]["count"] = data['TpsStatic']['VolumePost']['Tps_5XX'] 
          stat["post"]["traffic_20X"]["count"] = data['TpsStatic']['VolumePost']['Traffic_20X'] 
          #stat["post"]["sum"]["count"] = sum(data['TpsStatic']['VolumePost'].values()) / INTERNAL
          stat["post"]["sum"]["count"] = (stat["post"]["20X"]["count"] +
                                          stat["post"]["304"]["count"] +
                                          stat["post"]["3XX"]["count"] +
                                          stat["post"]["404"]["count"] +
                                          stat["post"]["4XX"]["count"] + 
                                          stat["post"]["5XX"]["count"] )
           
          stat["post"]["time"]=time.time()
       elif tps_type == "tps_filer":
          stat["get"]["20X"]["count"] = data['TpsStatic']['FilerGet']['Tps_20X'] 
          stat["get"]["304"]["count"] = data['TpsStatic']['FilerGet']['Tps_304'] 
          stat["get"]["3XX"]["count"] = data['TpsStatic']['FilerGet']['Tps_3XX'] 
          stat["get"]["404"]["count"] = data['TpsStatic']['FilerGet']['Tps_404'] 
          stat["get"]["4XX"]["count"] = data['TpsStatic']['FilerGet']['Tps_4XX'] 
          stat["get"]["5XX"]["count"] = data['TpsStatic']['FilerGet']['Tps_5XX'] 
          stat["get"]["traffic_20X"]["count"] = data['TpsStatic']['FilerGet']['Traffic_20X'] 
          #stat["get"]["sum"]["count"] = sum(data['TpsStatic']['FilerGet'].values()) / INTERNAL
          stat["get"]["sum"]["count"] = (stat["get"]["20X"]["count"] +
                                          stat["get"]["304"]["count"] +
                                          stat["get"]["3XX"]["count"] +
                                          stat["get"]["404"]["count"] +
                                          stat["get"]["4XX"]["count"] +
                                          stat["get"]["5XX"]["count"] )
          stat["get"]["time"] = time.time()
    #stat["traffic"] = data['TpsStatic']['FilerGet']['Tps_5XX'] + data['TpsStatic']['FilerPost']['Tps_5XX']
       #elif type == "post":
          stat["post"]["20X"]["count"] = data['TpsStatic']['FilerPost']['Tps_20X'] 
          stat["post"]["304"]["count"] = data['TpsStatic']['FilerPost']['Tps_304'] 
          stat["post"]["3XX"]["count"] = data['TpsStatic']['FilerPost']['Tps_3XX'] 
          stat["post"]["404"]["count"] = data['TpsStatic']['FilerPost']['Tps_404'] 
          stat["post"]["4XX"]["count"] = data['TpsStatic']['FilerPost']['Tps_4XX'] 
          stat["post"]["5XX"]["count"] = data['TpsStatic']['FilerPost']['Tps_5XX'] 
          stat["post"]["traffic_20X"]["count"] = data['TpsStatic']['FilerPost']['Traffic_20X'] 
          #stat["post"]["sum"]["count"] = sum(data['TpsStatic']['FilerPost'].values()) / INTERNAL
          stat["post"]["sum"]["count"] = (stat["post"]["20X"]["count"] +
                                          stat["post"]["304"]["count"] +
                                          stat["post"]["3XX"]["count"] +
                                          stat["post"]["404"]["count"] +
                                          stat["post"]["4XX"]["count"] +
                                          stat["post"]["5XX"]["count"] )
          stat["post"]["time"]=time.time()
       return stat

def get_pickle_data(f):
    obj=pickle.load(f)
    return obj

def dump_pickle_data(f,obj):
    return pickle.dump(obj,f)
