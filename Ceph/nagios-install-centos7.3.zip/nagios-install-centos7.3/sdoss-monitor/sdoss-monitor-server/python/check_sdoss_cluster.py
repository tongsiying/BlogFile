#!/usr/bin/python


print "OK"
