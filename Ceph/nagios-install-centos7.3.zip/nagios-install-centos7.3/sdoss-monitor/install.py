#!/usr/bin/python


import pexpect
from multiprocessing import Process  
import os  
import time 
import commands



paswd_key = '.*assword.*'
ssh_newkey = '.*(yes/no).*'
def get_hostip():
   cmd=''' ifconfig -a|grep Mask|grep -v 127.0.0.1 |awk '{print $2}'|awk -F":" '{print $2}' ''' 
   ip=commands.getstatusoutput(cmd)[1].split()[0]
   return ip

def write_log(host,t):
    file=os.path.split(os.path.realpath(__file__))[0] + '/log/' + host
    f=open(file,'a+')
    f.write(t)
    f.close()
   

def copy(host,passwd):
   try:
       foo = pexpect.spawn('''scp -r sdoss-monitor-install.sh sdoss-monitor-client root@%s:/tmp/''' % host)  
       i = foo.expect(['password:', 'continue connecting (yes/no)?'], timeout=30)
       if i == 0:
           foo.sendline(passwd)
       elif i == 1:
           foo.sendline('yes')
           foo.expect('password:')
           foo.sendline(passwd)
   except pexpect.EOF:
       foo.close()
       print "Scp files to host : " + host + " failed"
       write_log(host,"Scp files to host : " + host + " failed")
   else:
       r=foo.read()
       #print r
       write_log(host,r)
       foo.expect(pexpect.EOF)  
       foo.close()
       print "Scp file to host : " + host + " OK"
       write_log(host,"Scp file to host : " + host + " OK")
def install(host,passwd):    
   try:
       ip=get_hostip()
       foo = pexpect.spawn('''ssh root@%s -C  cd /tmp ; /tmp/sdoss-monitor-install.sh client %s ; cd -''' % (host,ip))
       i = foo.expect(['password:', 'continue connecting (yes/no)?'], timeout=30)
       if i == 0:
           foo.sendline(passwd)
       elif i == 1:
           foo.sendline('yes')
           foo.expect('password:')
           foo.sendline(passwd)
   except pexpect.EOF:
       foo.close()
       print "Install to host : " + host + " failed"
       write_log(host,"Install to host : " + host + " failed")
   else:
       r=foo.read()
#       print r
       write_log(host,r)
       foo.expect(pexpect.EOF)
       foo.close()
       if r.__contains__("succeed"):
          print "Install to host : " + host + " OK"
          write_log(host,"Install to host : " + host + " OK")
       else:
          print "Install to host : " + host + " Failed."
          write_log(host,"Install to host : " + host + " Failed.")

#   try:
#       ip=get_hostip()
       #foo = pexpect.spawn('ssh root@%s -f -C /etc/init.d/sdoss-monitor restart >/dev/null 2>&1' % (host))
       #i = foo.expect(['password:', 'continue connecting (yes/no)?'], timeout=30)
       #if i == 0:
       #    foo.sendline(passwd)
       #elif i == 1:
       #    foo.sendline('yes')
       #    foo.expect('password:')
       #    foo.sendline(passwd)
#   except pexpect.EOF:
#       foo.close()
#       print "Set service on host : " + host + " failed"
#       write_log(host,"Set service on host : " + host + " failed")
#   else:
#       r=foo.read()
#       write_log(host,r)
#       foo.expect(pexpect.EOF)
#       foo.close()
    
def installer(host,passwd):
    copy(host,passwd)
    time.sleep(3)
    install(host,passwd)


if __name__ == '__main__':
    path = os.path.split(os.path.realpath(__file__))[0] + '/' + 'install_host.csv'
    f=open(path)
    hosts=f.readlines()
    f.close()
    proc_list=[]
    for host in hosts:
        h= host.split()[0].split(",")[0]
        p= host.split()[0].split(",")[1]
        installer(h,p)
        #child_proc = Process(target=installer, args=(h, p))  
        #child_proc.start()  
        #proc_list.append(child_proc)
        #child_proc.join() 
    #for proc in proc_list:
        #proc.join()
