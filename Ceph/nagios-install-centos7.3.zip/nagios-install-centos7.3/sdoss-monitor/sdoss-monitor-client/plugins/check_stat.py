#!/usr/bin/python


import argparse
import commands

def parse_input():
    parser = argparse.ArgumentParser()
#    parser.add_argument("-w", "--warning", action="store",
#                        required=True, type=int,
#                        help="Warning threshold in percentage")
    parser.add_argument("-c", "--critical", action="store",
                        required=True, type=int,
                        help="Critical threshold ")
    parser.add_argument("-t", "--type", action="store",
                        required=True, type=str,
                        help="Check Type")
    args = parser.parse_args()
    return args


def get_stat():
    file='/usr/lib64/nagios/plugins/nginx_all.log'
    cmd=''
    if args.type == '200':
       cmd=' tail -n 1 ' + file + '''| awk '{print $14}' '''
    if args.type == '404':
       cmd=' tail -n 1 ' + file + '''| awk '{print $18}' '''
    if args.type == '304':
       cmd=' tail -n 1 ' + file + '''| awk '{print $22}' '''
    if args.type == 'sum':
       cmd=' tail -n 1 ' + file + '''| awk '{print $10}' '''
    if args.type == 'traffic':
       cmd=' tail -n 1 ' + file + '''| awk '{print $26}' '''
  
    out=commands.getstatusoutput(cmd) 
    if out[0] != 0:
          print "CRITICAL:Can not get nginx sum file!"
          exit(2)
    return float(out[1])
    


if __name__ == '__main__':
    try:
       msg=''
       code=0
       args=parse_input()
       r = get_stat()
       txt=''
       if args.type == 'traffic':
          txt='traffic'
       else:
          txt=args.type + 'tps'
       if r > args.critical:
           msg =  "CRITICAL: Check " + txt + " exceed threshold. return: " + str(r)
           code = 2
       else:
           msg =  "OK: Check " + txt + " OK. return: " + str(r)
           code = 0
       if args.type == 'traffic':
           msg +='KB'
       perfData="|" + txt + "=" + str(r) + ";" + str(args.critical) + ";" + str(args.critical) + ";0;" + str(r)
       msg += perfData
       print msg
       exit(code)
    except Exception as e:
       print e
       exit(2)
    
