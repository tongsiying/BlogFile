#!/usr/bin/python


import argparse
import commands
import time
import utils

def parse_input():
    parser = argparse.ArgumentParser()
    parser.add_argument("-w", "--warning", action="store",
                        required=True, type=int,
                        help="Warning threshold in percentage")
    parser.add_argument("-c", "--critical", action="store",
                        required=True, type=int,
                        help="Critical threshold in percentage")
    parser.add_argument("-t", "--type", action="store",
                        required=True, type=str,
                        help="Monitor type")
    args = parser.parse_args()
    return args 

def getPerfInfo(type,hostInfo):
    file='/usr/lib64/nagios/plugins/.nmon_all.log'
    if type == 'disk':
       cmd='cat %s |grep  DISKBUSY' %(file)
    if type == 'net':
       cmd='cat %s |grep  NET' %(file)
    if type == 'mem':
       cmd='cat %s |grep  MEM,' %(file)
    if type == 'cpu':
       cmd=''' cat %s |grep -E "CPU00|CPU_ALL" ''' %(file)
    msg=''
    tmpmsg=''
    out=commands.getstatusoutput(cmd)
    error = False
    if out[0] != 0:
        #print "Get Host Info Failed."
        return "",100
    if type == 'cpu':
       all_cpu=''
       cpu_msg=''
       out=out[1].split()
       count=len(out)
       for i in out:
           tmp = i.split(",") 
           if tmp[0] == "CPU_ALL":
                  tmpmsg = '''CPU Status OK: Total CPU:%.2f%% Idle CPU:%s%% ''' % (eval(tmp[2]+"+"+tmp[3]+"+"+tmp[4]),tmp[5])
                  code = 0
                  if float(tmp[5]) < (100 - args.warning):
                       tmpmsg = '''CPU Status WARNING: Total CPU:%.2f%% Idle CPU:%s%% ''' % (eval(tmp[2]+"+"+tmp[3]+"+"+tmp[4]),tmp[5])
                       code = 1
                  if float(tmp[5]) < 100 - args.critical:
                       tmpmsg = '''CPU Status CRITICAL: Total CPU:%.2f%% Idle CPU:%s%% ''' % (eval(tmp[2]+"+"+tmp[3]+"+"+tmp[4]),tmp[5])
                       code = 2
                  all_cpu= '''|num_of_cpu=%d cpu_all_total=%.2f%%;%d;%d cpu_all_system=%s%% cpu_all_user=%s%% cpu_all_idle=%s%% ''' % (count-1,eval(tmp[2]+"+"+tmp[3]+"+"+tmp[4]),args.warning,args.critical,tmp[3],tmp[2],tmp[5]) 
           else:
              index=int(tmp[0].replace("CPU","")) - 1
              cpu_msg+= "cpu_%d_total=%.2f%%;%d;%d cpu_%d_system=%s%% cpu_%d_user=%s%% cpu_%d_idle=%s%% " % (index,eval(tmp[2]+"+"+tmp[3]+"+"+tmp[4]),args.warning,args.critical,index,tmp[3],index,tmp[2],index,tmp[5])
       msg=tmpmsg + all_cpu + cpu_msg
       #return msg,code
 
    if type == 'mem':
       out=out[1].split(",")[2:]
       mem_total=utils.convertSize(float(out[0]),"MB","GB")
       buffered=utils.convertSize(float(out[12]),"MB","GB")
       cached=utils.convertSize(float(out[9]),"MB","GB")
       free=utils.convertSize(float(out[4]),"MB","GB") + buffered + cached
       msg=("- %.2f%% used(%.2fGB out of %.2fGB)|"
                 "Total=%.2fGB;%.2f;%.2f;0;%.2f "
                 "Used=%.2fGB Buffered=%.2fGB "
                 "Cached=%.2fGB" % ((mem_total-free)/mem_total*100,
                        mem_total-free,
                        mem_total,
                        mem_total,
                        args.warning * mem_total/100,
                        args.critical * mem_total/100,
                        mem_total,
                        mem_total - free, 
                        buffered,
                        cached))
       if free < float(mem_total) * (1 - float(args.critical) / 100):
              msg = "CRITICAL" + msg
              code = 2
       elif free < float(mem_total) * (1 - float(args.warning) / 100):
              msg = "WARNING" + msg
              code = 1
       else:
              msg = "OK" + msg
              code = 0
       #return msg,code
      
       
    if type == 'disk':
       out=out[1].split(",")[1:]
       hostInfo['disklist'] = out
    if type == 'net':
       msg=''
       code=0
       out=out[1].split()
       net=out[0].split(",")[2:]
       pkt=out[1].split(",")[2:]

       tmp_dict={}
       iflist=[]
       for i in range(len(hostInfo['netlist'])):
            if hostInfo['netlist'][i].__contains__("lo-") :
                continue
            else:
                iface=hostInfo['netlist'][i]
                ifname=iface.split("-")[0]
                iflist.append(ifname)
                tmp_dict[ifname] = {'rxpck':0,'rxkB':0,'txpck':0,'txkB':0}
       iflist=list(set(iflist))

       for i in range(len(hostInfo['netlist'])):
            if hostInfo['netlist'][i].__contains__("lo-") :
                continue
            else:
                iface=hostInfo['netlist'][i]
                ifname=iface.split("-")[0]
                #tmp_dict[ifname] = {'rxpck':0,'rxkB':0,'txpck':0,'txkB':0}
                if iface.__contains__(ifname+"-read-KB/s"):
                   tmp_dict[ifname]['rxpck'] = float(pkt[i]) * 5
                   tmp_dict[ifname]['rxkB'] = float(net[i])
                if iface.__contains__(ifname+"-write-KB/s"):
                   tmp_dict[ifname]['txpck'] = float(pkt[i]) * 5
                   tmp_dict[ifname]['txkB'] = float(net[i])
       #for net in tmp_dict.keys():
       #    msg="%s.rxpck=%.2f; %s.txpck=%.2f; %s.rxkB=%.2f; %s.txkB=%.2f" % (net,tmp_dict[net]
       r_if=[]
       t_if=[]
       code=0
       for i in iflist: 
             if tmp_dict[i]['rxkB']/1024 > args.critical: 
                 r_if.append((i,tmp_dict[i]['rxkB']))
                 code=1
             if tmp_dict[i]['txkB']/1024 > args.critical:
                 t_if.append((i,tmp_dict[i]['txkB']))
                 code+=2
       if code==0: 
          tmp_str=''
          for i in iflist:
             tmp_str += str(i)
          msg="OK:%s is up" % (tmp_str)
       elif code>0 and code<4:
          msg="CRITICAL: "
          if code == 1:
             for (i,j) in r_if:
                msg="%s receiving rate greater than %d MB, return: %sKB" %(str(i),args.warning,str(j))
          if code==2:
             for (i,j) in t_if:
                msg="%s transmission rate greater than %d MB, return: %sKB" %(str(i),args.critical,str(j))
          if code==3:
             for (i,j) in r_if:
                msg+="%s receiving rate greater than %d MB, return: %sKB;" %(str(i),args.warning,str(j))
             for (i,j) in t_if:
                msg+="%s transmission rate greater than %d MB, return: %sKB" %(str(i),args.critical,str(j))
       msg+="|"
       for i in iflist:
           msg+="%s.rxpck=%.2f %s.txpck=%.2f %s.rxkB=%.2f %s.txkB=%.2f " % (i,tmp_dict[i]['rxpck'],i,tmp_dict[i]['txpck'],i,tmp_dict[i]['rxkB'],i,tmp_dict[i]['txkB'])
    return msg,code
                
                  
       
       

def getHostInfo(file,type):
    hostInfo = { 'disklist': [],
                 'cpulist': [],
                 'netlist': [],
                 'memlist': []
               }
                             
    basecmd='head %s -n 1000|grep -m 1 ZZZZ, -B 1000|grep ' %(file)

    typelist = ['mem','cpu','net','disk']
    for type in typelist:
        cmd=""
        if type == 'disk':
           cmd=basecmd + ''' DISKBUSY|awk '{print $3}' '''
        if type == 'net':
           cmd=basecmd + ''' NET,|awk '{print $3}' '''
        if type == 'mem':
           cmd=basecmd + ''' MEM,|awk '{print $3}' '''
        if type == 'cpu':
           cmd=basecmd + ''' CPU00|awk -F"," '{print $1}' '''
        out=commands.getstatusoutput(cmd)     
        if out[0] != 0:
           print "Nmon Progress Not Started."
           return
        if type == 'cpu':
           out=out[1].split()
           hostInfo['cpulist'] = out
        if type == 'mem':
           out=out[1].split(",")[1:]
           hostInfo['memlist'] = out
        if type == 'disk':
           out=out[1].split(",")[1:]
           hostInfo['disklist'] = out
        if type == 'net':
           out=out[1][:-1].split(",")[1:]
           hostInfo['netlist'] = out
    return hostInfo

#def getTimeCount(file,t=5):
    #cmd=''' head %s -n 1000|grep ZZZZ,T0001|awk -F"," '{print $3}' ''' %(file)
    #out=commands.getstatusoutput(cmd)
    #if out[0] != 0:
    #     print "Get nmon file failed."
    #     return
    #out=out[1].split(":")     
    #print out
#    tmp=time.localtime(time.time())
#    tick = ((tmp.tm_hour-int(out[0]))*3600 + (tmp.tm_min-int(out[1])) * 60 + tmp.tm_sec - int(out[2])) / t
#    tick = (tmp.tm_hour*3600 + tmp.tm_min * 60 + tmp.tm_sec) / t
#    print tick

    


     
if __name__=='__main__':
    try:
       args=parse_input()
       cmd='hostname'
       hostname=commands.getstatusoutput(cmd)[1]
       cmd='''ls -ltr /opt/nmon/%s_*.nmon|tail -n 1|awk '{print $9}' ''' %(hostname)
       file=commands.getstatusoutput(cmd)[1]
       hostInfo=getHostInfo(file,args.type)
       msg,code=getPerfInfo(args.type,hostInfo)
       if code == 100:
           cmd = ''' ps -ef|grep nmon |grep 17280 |grep -v grep '''
           out=commands.getstatusoutput(cmd)
           if out[0] != 0:
                 print "nmon progress not start!"
                 exit(2)
           msg= "OK"
           code=0
       
       print msg
       exit(code)
    except Exception as e:
       print e
       exit(2)
