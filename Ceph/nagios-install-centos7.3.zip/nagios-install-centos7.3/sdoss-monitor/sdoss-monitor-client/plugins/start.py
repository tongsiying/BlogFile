#!/usr/bin/python

import sys
import commands
from subprocess import Popen,PIPE

if __name__ == '__main__':
    cmd=''
    if  sys.argv[1] == 'start':
        #cmd='''/usr/lib64/nagios/plugins/start.sh start'''
        f=Popen(('/usr/lib64/nagios/plugins/start.sh', 'start'),stdout=PIPE).stdout
        data=f.readline()
        print data
    elif sys.argv[1] == 'stop':
        f=Popen(('/usr/lib64/nagios/plugins/start.sh', 'stop'),stdout=PIPE).stdout
        data=f.readline()
        print data
    #commands.getstatusoutput(cmd)
    exit(0)
