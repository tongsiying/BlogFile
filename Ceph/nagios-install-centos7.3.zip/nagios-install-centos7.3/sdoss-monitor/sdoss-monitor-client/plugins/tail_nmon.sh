#!/bin/sh
pid=$$
#log_path=`ps -ef|grep weed|grep -v -E '"grep|avahi|vim"'|grep -E '"volume|server|master"'|tr '" "' '"\n"'|grep log|awk -F"=" '{print $2}'`
#file="$log_path/weed.INFO $log_path/weed.VOLUMEHTTP"
#allfile="$log_path/weed.INFO $log_path/weed.VOLUMEHTTP $log_path/weed.FILERHTTP"
hostname=`hostname`
nmonfile=`ls -ltr /opt/nmon/$hostname_*.nmon|tail -n 1|awk '{print $9}'`
#tail -f $file --pid=$pid -s 0.1 -n 0 > .tail.log &
#tail -f $allfile --pid=$pid -s 0.1 -n 0 > .tail_all.log &
tail -f $nmonfile --pid=$pid -s 0.1 -n 0 > .nmon.log &
sleep 5
#mv tail.log tail.log.$$
#\mv .tail.log .sdoss_status.log
#\mv .tail_all.log .sdoss_all.log
\mv .nmon.log .nmon_all.log
exit 0

