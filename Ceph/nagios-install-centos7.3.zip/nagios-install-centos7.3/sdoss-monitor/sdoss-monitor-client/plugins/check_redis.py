#!/usr/bin/python

import commands
import time

def check_redis():
    status=0
    msg=""
    ports=commands.getstatusoutput("cat /etc/redis/*.conf|grep port|grep -v ^#|awk '{print $2}'")
    ports=ports[1].split()
    for port in ports:
        cmd='ps -ef|grep redis|grep -v grep | grep  ' + str(port) 
        result=commands.getstatusoutput(cmd)
        if result[0] != 0:
           status =result[0]
           msg += "Check " + str(port) + " failed, return code " + str(status)+ " : " + result[1] + "\n"
        time.sleep(1)
    return status,msg


if __name__ == '__main__':

    status,msg = check_redis()
    if status == 0:
       print "OK. ALL redis server OK."
       exit(0)
    else :
       print "Critical. Check redis failed."
       print msg
       exit(2) 
