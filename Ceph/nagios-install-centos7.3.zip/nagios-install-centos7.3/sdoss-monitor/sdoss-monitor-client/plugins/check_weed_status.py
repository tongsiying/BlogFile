#!/usr/bin/python
import commands
import sys


if __name__ == '__main__':
   try:
      msg = ''
      code = 0
      status={"master":"NA","filer":"NA","volume":"NA","account":"NA","bucket":"NA"}
      type=sys.argv[1]
      if "master" in type:
          cmd=''' ps -ef|grep weed|grep " master "|grep -v "\-master"|grep -v grep|grep -v python |grep -v tail|grep -v check_weed_status'''
          out=commands.getstatusoutput(cmd)
          if out[0] != 0:
             status["master"] = "NOK"
          else:
             status["master"] = "OK"
      if "filer" in type:
          cmd=''' ps -ef|grep weed|grep  " filer "|grep -v grep|grep -v python|grep -v tail|grep -v check_weed_status '''
          out=commands.getstatusoutput(cmd)
          if out[0] != 0:
             status["filer"] = "NOK"
          else:
             status["filer"] = "OK"
      if "volume" in type:
          cmd=''' ps -ef|grep weed|grep  " volume "|grep -v grep |grep -v python|grep -v tail|grep -v check_weed_status'''
          out=commands.getstatusoutput(cmd)
          if out[0] != 0:
             status["volume"] = "NOK"
          else:
             status["volume"] = "OK"
      if "account" in type:
          cmd=''' ps -ef|grep weed|grep  " Account " |grep -v grep |grep -v python|grep -v tail |grep -v check_weed_status'''
          out=commands.getstatusoutput(cmd)
          if out[0] != 0:
             status["account"] = "NOK"
          else:
             status["account"] = "OK"
      if "bucket" in type:
          cmd=''' ps -ef|grep weed|grep  " Bucket "|grep -v grep |grep -v python|grep -v tail |grep -v check_weed_status'''
          out=commands.getstatusoutput(cmd)
          if out[0] != 0:
             status["bucket"] = "NOK"
          else:
             status["bucket"] = "OK"
      if status["master"] == "NOK" or status["filer"] == "NOK" or status["volume"] == "NOK"  or status["account"] == "NOK" or status["bucket"] == "NOK":
           code = 2
       
      if code == 0:
         msg = "OK:"
      else:
         msg = "CRITICAL:"
      msg += "master:" + status["master"] + " filer:" + status["filer"]+ " volume:" + status["volume"] + " account:" + status["account"] + " bucket:" + status["bucket"]
      print msg
      exit(code)
   except Exception as e:
      print e
      exit(2)
