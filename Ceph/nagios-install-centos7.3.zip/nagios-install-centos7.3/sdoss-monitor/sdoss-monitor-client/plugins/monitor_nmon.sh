#!/bin/sh


while true
do
    ./tail_nmon.sh >/dev/null 2>&1 
done
