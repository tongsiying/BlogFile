#!/bin/sh  
pid=$$
master_path=`ps -ef|grep weed|grep -v -E '"grep|avahi|vim"'|grep master|grep -v filer|grep -v grep|tr '" "' '"\n"'|grep log|awk -F"=" '{print $2}'`
filer_path=`ps -ef|grep weed|grep -v -E '"grep|avahi|vim"'|grep filer|grep -v grep|tr '" "' '"\n"'|grep log|awk -F"=" '{print $2}'|grep -v subfiler`
volume_path=`ps -ef|grep weed|grep -v -E '"grep|avahi|vim"'|grep volume|grep -v master|grep -v filer|grep -v grep|tr '" "' '"\n"'|grep log|awk -F"=" '{print $2}'`
subfiler_path=`ps -ef|grep weed|grep -v -E '"grep|avahi|vim"'|grep subfiler|grep -v grep|tr '" "' '"\n"'|grep log|awk -F"=" '{print $2}'`
#filer_dir=
#for i in $filer_path
#do
#   n=`basename $i`
#   if [ $n = 'filer' ]
#   then
#      filer_dir=`dirname $i`
#   fi
#done
master_path=($master_path)
filer_path=($filer_path)
volume_path=($volume_path)
subfiler_path=($subfiler_path)
#echo $master_path
round_path=/opt/log/sdoss/master

#if [ "x$master_path" != "x" ]
#then
  tail -f $master_path/weed.INFO  $filer_path/weed.INFO   $volume_path/weed.INFO  --pid=$pid -s 0.1 -n 0 > $round_path/.tail_master.log &
#fi

#if [ "x$filer_path" != "x" ]
#then
#  tail -f $filer_path/weed.INFO --pid=$pid -s 0.1 -n 0 > $filer_path/.tail_filer.log &
#fi

#if [ "x$subfiler_path" != "x" ]
#then
#  tail -f $subfiler_path/weed.INFO --pid=$pid -s 0.1 -n 0 > $subfiler_path/.tail_subfiler.log &
#fi

#if [ "x$volume_path" != "x" ]
#then
#tail -f $volume_path/weed.INFO --pid=$pid -s 0.1 -n 0 > $volume_path/.tail_volume.log  &
#fi

sleep 3600

\cp $round_path/.tail_master.log $round_path/master.log #>/dev/null 2>&1
#\cp $filer_path/.tail_filer.log $filer_path/filer.log #>/dev/null 2>&1
#\cp $subfiler_path/.tail_subfiler.log $subfiler_path/subfiler.log #>/dev/null 2>&1
#cp $volume_path/.tail_volume.log $volume_path/volume.log #>/dev/null 2>&1
exit 0

