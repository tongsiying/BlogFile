#!/bin/bash
ip=`/sbin/ifconfig -a|grep -v 192.168.122.1|grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|awk -F':' '{print $2}'`
master_path="/opt/log/sdoss/master"
MASTER_FILE=$master_path/master.log

pid=`ps -ef |grep "tail -f /opt/log/sdoss/master/weed.INFO /opt/log/sdoss/volume/weed.INFO /opt/log/sdoss/filer/weed.INFO -n 0"|grep -v grep|awk '{print $2}'`
  if [ ! -z "$pid" ]
  then
     sudo  \cp /opt/log/sdoss/master/.master.log /opt/log/sdoss/master/master.log
     kill $pid
     tail -f /opt/log/sdoss/master/weed.INFO /opt/log/sdoss/volume/weed.INFO /opt/log/sdoss/filer/weed.INFO -n 0 > /opt/log/sdoss/master/.master.log &
  else
     tail -f /opt/log/sdoss/master/weed.INFO /opt/log/sdoss/volume/weed.INFO /opt/log/sdoss/filer/weed.INFO -n 0 > /opt/log/sdoss/master/.master.log &
  fi

   all_msg=""
   IFS=,
   while read type des code
   do
     t=`cat ${MASTER_FILE} | awk '{print $6" "$7}'|grep -E "UPLOAD|DELETE|DOWNLOAD|FIX|VACUUM"|grep  " ${code} " |wc -l` # >/dev/null 2>&1
     if [ $t -ne 0 ]
     then
        msg=${ip}" "${code}" "${t}
       #write_file "$msg"
        if [ -z $all_msg ]
        then
          all_msg=${msg}
        else
          all_msg=$all_msg" "${msg}
        fi
    fi
   done < /usr/lib64/nagios/plugins/round_check/msg.csv
   IFS=
   echo >${MASTER_FILE}
   if [ -z $all_msg ]
   then
     echo "none"
   else
     echo $all_msg
   fi

  #cat /opt/log/sdoss/master/master.log |grep -E "UPLOAD|DOWNLOAD|DELETE|FIX|VACUUM"
