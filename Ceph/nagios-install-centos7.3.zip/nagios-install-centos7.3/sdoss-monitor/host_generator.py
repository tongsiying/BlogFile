#!/usr/bin/python

import ConfigParser
import os
import commands

FILE='host.conf'
def getConfig(section='sdoss', key='hosts'):
    config = ConfigParser.ConfigParser()
    path = os.path.split(os.path.realpath(__file__))[0] + '/' + FILE
    config.read(path)
    s=config.options(section)
    if key in s :
       return config.get(section, key)
    else:
       return []

def getSections():
    config = ConfigParser.ConfigParser()
    path = os.path.split(os.path.realpath(__file__))[0] + '/' + FILE
    config.read(path)
    return config.sections()

def generateHostCfg(host,grouplist,master_hosts,volume_hosts,filer_hosts,account_hosts,bucket_hosts,cluster):
    config=""
    config+="define host {\n"
    config+="    alias        " + host + "\n"
    if grouplist.__contains__('cluster_hosts'):
         #config+="    use          generic-host\n"
         config+="    use          weed-cluster\n"
    else:
         config+="    use          weed-generic-host\n"
    config+="    host_name     " + host + "\n"
    config+="    alias        " + host + "\n"
    #if grouplist.__contains__('cluster_hosts'):
    #     config+="    host_groups  " + grouplist + ",cluster_hosts" + "\n"
    #else:
    #     config+="    host_groups  " + grouplist + "\n"
    config+="    host_groups  " + grouplist + "\n"
    if grouplist.__contains__('cluster_hosts'):
         if master_hosts=='':
            master_hosts='None' 
         config+="    _master_list  " + master_hosts + "\n"
         config+="    _volume_list  " + volume_hosts + "\n"
         config+="    _filer_list  " + filer_hosts + "\n"
         config+="    _account_list  " + account_hosts + "\n"
         config+="    _bucket_list  " + bucket_hosts + "\n"
    config+="    _cluster     " + cluster + "\n"
    type = ""
    if host in master_hosts:
          type += "master,"
    if host in volume_hosts:
          type += "volume,"
    if host in filer_hosts:
          type += "filer,"
    if host in account_hosts:
          type += "account,"
    if host in bucket_hosts:
          type += "bucket,"
    if type == "":
       type = "none"
    else:
       type = type[:-1]
    config+="    _type     " + type + "\n"
    config+="}\n"
    return config

    

if __name__ == '__main__':
  try:
   clusters=getSections()
   config=""
   for cluster in clusters:
       hosts=getConfig(section=cluster,key='hosts')
       hosts=hosts.split(",")
   
       nginx_hosts=getConfig(section=cluster,key='nginx_server').split(",")
       volume_hosts=getConfig(section=cluster,key='volume_server')#.split(",")
       master_hosts=getConfig(section=cluster,key='master_server')
       filer_hosts=getConfig(section=cluster,key='filer_server')
       redis_hosts=getConfig(section=cluster,key='redis_server').split(",")
       mysql_hosts=getConfig(section=cluster,key='mysql_server').split(",")
       account_hosts=getConfig(section=cluster,key='account_server')
       bucket_hosts=getConfig(section=cluster,key='bucket_server')
       for host in hosts:
            grouplist="common_hosts"
            if host in nginx_hosts:
                 grouplist +=',nginx_hosts'
            #if host in volume_hosts:
            if volume_hosts.__contains__(host):
                 grouplist += ',' + 'volume_hosts'
            if host in master_hosts:
                 grouplist += ',' + 'master_hosts'
            if host in filer_hosts:
                 grouplist += ',' + 'filer_hosts'
            if host in redis_hosts:
                 grouplist += ',' + 'redis_hosts'
            if host in mysql_hosts:
                 grouplist += ',' + 'mysql_hosts'
            if host in account_hosts:
                 grouplist += ',' + 'account_hosts'
            if host in bucket_hosts:
                 grouplist += ',' + 'bucket_hosts'
  
            config+=generateHostCfg(host,grouplist,master_hosts,volume_hosts,filer_hosts,account_hosts,bucket_hosts,cluster) 
       config+=generateHostCfg(cluster,'cluster_hosts',master_hosts,volume_hosts,filer_hosts,account_hosts,bucket_hosts,cluster)
       nginx_hosts=[]
       volume_hosts=''
       master_hosts=''
       redis_hosts=[]
       mysql_hosts=[]
       account_hosts=''
       bucket_hosts=''
   #print config
   weed_cfgfile='/etc/nagios/conf.d/weed.cfg'
   f=open(weed_cfgfile,'w')
   f.write(config)
   f.close()

   cmd='service nagios restart'
   commands.getstatusoutput(cmd)
  except Exception as e:
      print e
      exit(1)
