MAC currently not supported in this release. 
I need a volunteer to do a small C compile and link.
Email me at Henk.Vandenbergh@oracle.com
