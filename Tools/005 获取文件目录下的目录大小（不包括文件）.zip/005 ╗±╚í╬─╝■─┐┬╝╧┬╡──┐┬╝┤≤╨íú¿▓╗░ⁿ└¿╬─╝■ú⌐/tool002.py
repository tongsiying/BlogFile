#coding:utf-8

import os
import os.path
import sys

global_path = ""
def get_size(path):
    list = []
    dirsize = 0
    fileList = os.listdir(path)
    for filename in fileList:
        pathTmp = os.path.join(path,filename)  
        if os.path.isdir(pathTmp):  
           dirsize = get_size(pathTmp)
           list.append(dirsize)        
        elif os.path.isfile(pathTmp):  
            filesize = os.path.getsize(pathTmp)
            list.append(filesize)

    father_path = os.path.abspath(os.path.dirname(path) + os.path.sep + ".")
    name = os.path.basename(path)
    size = sum(list)
    global global_path
    if father_path == global_path:
        print('%s : %d KB' % (name,size/1024))
    return size

global_path = sys.argv[1]
size = get_size(global_path)
