#coding:utf-8

import os
import os.path
import sys
list = []
def get_size(path):
    list1 = []
    fileList = os.listdir(path)  
    for filename in fileList:
        pathTmp = os.path.join(path,filename)  
        if os.path.isdir(pathTmp):  
            get_size(pathTmp)        
        elif os.path.isfile(pathTmp):  
            filesize = os.path.getsize(pathTmp)
            #print('file size：%d B' % filesize)
            list1.append(filesize)
            list.append(filesize)
    print('%s : %d B' % (path,sum(list1)))

#path = input("dir:").strip()
path = sys.argv[1]
get_size(path)
print('total size:%d B' % sum(list))
