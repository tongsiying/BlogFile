#!/bin/bash
function vsftpd_usage() {
pkill vsftpd
rpm -ivh --force ./vsftpd-2.2.2-11.el6.x86_64.rpm >>/dev/null 2>&1
service vsftpd start
adduser -s /bin/bash -d $ftp_path $user
echo "$password" | passwd $user --stdin > /dev/null 2>&1
sed -i 's/anonymous_enable=YES/anonymous_enable=NO/g' /etc/vsftpd/vsftpd.conf
sed -i 's/#chroot_list_enable=YES/chroot_list_enable=YES/g' /etc/vsftpd/vsftpd.conf
sed -i 's/#chroot_list_file/chroot_list_file/g' /etc/vsftpd/vsftpd.conf
sed -i 's/#chroot_local_user=/chroot_local_user=/g' /etc/vsftpd/vsftpd.conf
echo "userlist_deny=NO" >>/etc/vsftpd/vsftpd.conf
echo "userlist_file=/etc/vsftpd/user_list" >>/etc/vsftpd/vsftpd.conf
echo "$user" >>/etc/vsftpd/chroot_list 
echo "$user" >>/etc/vsftpd/user_list
service vsftpd restart
}

while getopts "u:r:w:i:h" opt
do
    case $opt in
        u)
        user=$OPTARG
        ;;
        r)
        ftp_path=$OPTARG
        ;;
        w)
        password=$OPTARG
        ;;
        i)
        vsftpd_usage
        ;;
        h)
        echo "----help: sh vsftpd-insatll.sh -u username -r ftp_path -w userpasswd -i"
		echo "-u ftp用户"
		echo "-r 指定ftp的路径"
		echo "-w 指定ftp用户的密码"
        ;;
        ?)
        echo "-h查看使用方法"
        exit 1;;
    esac
done