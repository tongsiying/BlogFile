#!/bin/bash
hostname1=sdfspstapp04
a=()
a=`ls *.txt`
pid=$$
thread=200
tmp_fifo="/tmp/$$.fifo"
mkfifo $tmp_fifo
exec 8<>$tmp_fifo
rm $tmp_fifo
for i in $(seq 1 $thread)
do
    echo
done >&8

for item in ${a[@]}
do
        read -u8
        {
		i=0
		b=()
		c=()
		b=`cat ${item}|awk '{print $5}'`
		c=`cat ${item}|awk '{print $3}'`
		c_txt=`echo ${c[@]}`
		for item2 in ${b[@]}
		do
			b_md5=`echo -n "${item2}"|md5sum|sed 's/ -//g'`
			list[$i]=$b_md5
			i=`expr $i + 1`
		done
		list_test=`echo ${list[@]}`
		if [ "$c_txt" != "$list_test" ];then
                	echo $item >>error.log
        	fi
		first_num=`cat ${item}|grep "$hostname1" |awk '{print $2}'|sort|uniq|head -1`
		end_num=`cat ${item} |grep "$hostname1"|awk '{print $2}'|sort|uniq|tail -1`	
		D1=`expr $end_num - $first_num + 1`
		D2=`cat ${item}|grep "$hostname1" |awk '{print $2}'|sort|uniq|wc -l`
		if [ "$D1" != "$D2" ];then
                       echo $item >>error.log
                fi
		D3=`cat 1.txt |awk '{print $4}'|uniq`
		if [ "$D3" != - ];then
                       echo $item >>error.log
                fi
        echo "" >&8
        } &
done

wait
exec 8>&-
