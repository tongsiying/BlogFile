#!/bin/bash
function rand(){
    min=$1
    max=$(($2-$min+1))
    num=$(cat /proc/sys/kernel/random/uuid | cksum | awk -F ' ' '{print $1}')
    echo $(($num%$max+$min))
}

num=11
num_txt_max=10001
for((i=1; i<${num}; i++));do
		for((j=1; j<${num_txt_max}; j++));do
		rnd=$(rand 100000000 1000000000)
		rnf=$(rand 100000000 1000000000)
		a=`echo $rnd$rnf`
		b=`echo -n "$rnd$rnf"|md5sum`
		c=`date +%s`
		d=`hostname`
		echo -e "$d\t$c\t$b\t$a" >>"$i".txt
		done
done
