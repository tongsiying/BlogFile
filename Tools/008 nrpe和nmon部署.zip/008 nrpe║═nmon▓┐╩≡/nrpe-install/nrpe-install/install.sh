#!/bin/bash
pkill nrpe
ps -ef|grep nmon|grep -v grep|awk '{print $2}'|xargs kill>/dev/null 2>&1
useradd nrpe 1>/dev/null 2>/dev/null
rpm -ivh --force ./rpms-rhel63/nagios-common-3.5.1-1.el6.x86_64.rpm >>/dev/null 2>&1
rpm -ivh --force ./rpms-rhel63/nrpe-2.15-2.el6.x86_64.rpm >>/dev/null 2>&1 
rpm -ivh --force ./rpms-rhel63/gluster-nagios-common-0.1.1-0.el6.noarch.rpm >>/dev/null 2>&1
cp -r ./nrpe /usr/sbin/
mkdir -p /etc/nagios/
cp -r ./nrpe.cfg /etc/nagios/
cp -r ./nagios.tar.gz /usr/lib64/;tar -zxvf /usr/lib64/nagios.tar.gz -C /usr/lib64/>>/dev/null 2>&1;rm -rf /usr/lib64/nagios.tar.gz
cp -r ./check_nrpe /usr/lib64/nagios/plugins/
chmod -R +x /usr/lib64/nagios/plugins/*
sed -i "/allowed_hosts=/s/.*/#allowed_hosts=/g" /etc/nagios/nrpe.cfg
chmod 777 /etc/sudoers
cat /etc/sudoers |grep "nagios ALL=(ALL) NOPASSWD:ALL" >/dev/null
if [[ $? -ne 0 ]]
then
    echo "nagios ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers
fi
cat /etc/sudoers |grep "nrpe ALL=(ALL) NOPASSWD:ALL" >/dev/null
if [[ $? -ne 0 ]]
then
    echo "nrpe ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers
fi
sed -i '/Defaults requiretty/s/.*/#Defaults requiretty/g' /etc/sudoers
sed -i '/Defaults    requiretty/s/.*/#Defaults requiretty/g' /etc/sudoers
chmod 440 /etc/sudoers
cp -r ./nrpe-init.d/nrpe /etc/init.d/
chmod +x /etc/init.d/nrpe
chkconfig --add nrpe
service nrpe start
chkconfig nrpe on >/dev/null
service iptables stop 1>/dev/null 2>/dev/null

mkdir -p /opt/nmon/
mkdir -p /nmon
ls /nmon/nmon*>/dev/null
if [ $? -ne 0 ];then
	cp ./nmon_x86_rhel6 /nmon
fi
/nmon/nmon_x86_64_rhel6 -f -N -m /nmon -s 60 -c 1440
/nmon/nmon_x86_64_rhel6 -f -N -m /opt/nmon -s 5 -c 17280
cd /usr/lib64/nagios/plugins/
nohup bash ./monitor_nmon.sh >>/dev/null 2>&1 &

service nrpe start 1>/dev/null 2>/dev/null

crontab -l > crontab.bak
cat crontab.bak|grep -q nmon_check.sh
if [ $? -eq 0 ];then
    rm -rf crontab.bak
    echo "[info][$(date +'%F %H:%M:%S')]nmon_check Already Exists..."
else
	nmon_p=`pwd`
    echo "0 */1 * * * sh $nmon_p/nmon_check.sh" >> crontab.bak
    crontab crontab.bak
    rm -rf crontab.bak
    echo "[info][$(date +'%F %H:%M:%S')]nmon_check Add..."
fi
