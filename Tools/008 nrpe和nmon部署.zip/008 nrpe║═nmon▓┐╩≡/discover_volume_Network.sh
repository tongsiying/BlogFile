#!/bin/bash
function discover_volume_Network() {
#while true
#do
cat /proc/net/dev |sed 's/:/ /g'|awk '{print $1}'|grep -q $OPTARG 
if [ $? -eq 0 ];then
  RX_pre=$(cat /proc/net/dev | grep $OPTARG | sed 's/:/ /g' | awk '{print $2}')
  TX_pre=$(cat /proc/net/dev | grep $OPTARG | sed 's/:/ /g' | awk '{print $10}')
  sleep 1
  RX_next=$(cat /proc/net/dev | grep $OPTARG| sed 's/:/ /g' | awk '{print $2}')
  TX_next=$(cat /proc/net/dev | grep $OPTARG | sed 's/:/ /g' | awk '{print $10}')
 
  #clear
  #echo -e "\t RX `date +%k:%M:%S` TX"
 
  RX=$((${RX_next}-${RX_pre}))
  TX=$((${TX_next}-${TX_pre}))
 
  if [[ $RX -lt 1024 ]];then
    RX="${RX}B"
  elif [[ $RX -gt 1048576 ]];then
    RX=$(echo $RX | awk '{print $1/1048576 "MB"}')
  else
    RX=$(echo $RX | awk '{print $1/1024 "KB"}')
  fi
 
  if [[ $TX -lt 1024 ]];then
    TX="${TX}B"
  elif [[ $TX -gt 1048576 ]];then
    TX=$(echo $TX | awk '{print $1/1048576 "MB"}')
  else
    TX=$(echo $TX | awk '{print $1/1024 "KB"}')
  fi
 
  echo -e "$OPTARG,$RX,$TX "
 
#done
else
	echo "404"
fi
}

while getopts "a:" opt
do
    case $opt in
        a)
        discover_volume_Network
        ;;
        ?)
        echo "未知参数"
        exit 1;;
    esac
done