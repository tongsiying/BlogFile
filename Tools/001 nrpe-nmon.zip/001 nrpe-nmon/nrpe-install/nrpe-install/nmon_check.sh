#!/bin/sh
nmon_path=`ls /nmon/nmon*`
function nmon17280_Monitor() {
ps -ef|grep nmon|grep 17280|grep -v grep>>/dev/null 2>&1
if [ $? -eq 0 ];then
    echo "[info][$(date +'%F %H:%M:%S')]nmon17280 is running......"
else
        echo "[info][$(date +'%F %H:%M:%S')]nmon17280 Dead,Ready To Start nmon17280..."
        $nmon_path -f -N -m /opt/nmon -s 5 -c 17280
    ps -ef|grep nmon|grep 17280|grep -v grep>>/dev/null 2>&1
        if [ $? -eq 0 ];then
                echo "[info][$(date +'%F %H:%M:%S')]nmon17280 Start success......"
        else
                echo "[info][$(date +'%F %H:%M:%S')]nmon17280 start failed......"
        fi
fi
}

function nmon1440_Monitor() {
ps -ef|grep nmon|grep 1440|grep -v grep>>/dev/null 2>&1
if [ $? -eq 0 ];then
    echo "[info][$(date +'%F %H:%M:%S')]nmon1440 is running......"
else
        echo "[info][$(date +'%F %H:%M:%S')]nmon1440 Dead,Ready To Start nmon1440..."
        $nmon_path -f -N -m /nmon -s 60 -c 1440
    ps -ef|grep nmon|grep 1440|grep -v grep>>/dev/null 2>&1
        if [ $? -eq 0 ];then
                echo "[info][$(date +'%F %H:%M:%S')]nmon1440 Start success......"
        else
                echo "[info][$(date +'%F %H:%M:%S')]nmon1440 start failed......"
        fi
fi
}

nmon17280_Monitor >>/tmp/nmon17280.log
nmon1440_Monitor >>/tmp/nmon1440.log

